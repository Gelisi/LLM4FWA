
import random
import numpy as np
from typing import List, Dict, Tuple
import copy
import time

class FWA:
    def __init__(
        self,
        evaluator: callable,  # 评估函数：input -> fitness (越小越好)
        num_planes: int,      # 飞机数量
        num_runways: int,     # 跑道数量
        planes: List[Dict],   # 飞机信息（含"earliest"/"latest"/"target"/"penalty_early"/"penalty_late"）
        separation: List[List[float]],  # 间隔矩阵（separation[i][j] = i早于j的最小间隔）
        fw_size: int = 20,    # 烟花数量（种群大小）
        sp_size: int = 50,    # 总火花数（所有烟花爆炸产生的火花总数）
        init_amp: float = 1,  # 初始爆炸幅度（时间扰动比例，相对于时间窗长度）
        max_iter: int = 200,  # 最大迭代次数
        mutation_rate: float = 0.5,  # 变异概率
    ):
        self.evaluator = evaluator
        self.num_planes = num_planes
        self.num_runways = num_runways
        self.planes = planes
        self.separation = np.array(separation)
        self.fw_size = fw_size
        self.sp_size = sp_size
        self.init_amps = init_amp
        self.max_iter = max_iter
        self.mutation_rate = mutation_rate
        self.silent = 0
        self.earliest_landing_times = np.array([self.planes[index]["earliest"] for index in range(self.num_planes)])
        self.target_landing_times = np.array([self.planes[index]["target"] for index in range(self.num_planes)])
        self.latest_landing_times = np.array([self.planes[index]["latest"] for index in range(self.num_planes)])
        self.penalty_early = np.array([self.planes[index]['penalty_early'] for index in range(self.num_planes)])
        self.penalty_late = np.array([self.planes[index]['penalty_late'] for index in range(self.num_planes)])
        self.amps = [init_amp] * fw_size
        self.population = []
        self.fitness_values = []
        self.epsilon = 1e-5
        self.initialize_population()

    def initialize_population(self):
        self.population = []
        plane_indices = list(range(self.num_planes))
        target_times = [self.planes[i]["target"] for i in range(self.num_planes)]
        
        for _ in range(self.fw_size):
            runway_assignments = np.random.randint(1, self.num_runways + 1, self.num_planes)
            runway_planes = {i: [] for i in range(1, self.num_runways + 1)}
            
            for plane_idx in range(self.num_planes):
                runway = runway_assignments[plane_idx]
                runway_planes[runway].append(plane_idx)
            
            for runway in runway_planes:
                runway_targets = [target_times[plane_idx] for plane_idx in runway_planes[runway]]
                sorted_indices = sorted(range(len(runway_targets)), key=lambda k: runway_targets[k])
                runway_planes[runway] = [runway_planes[runway][i] for i in sorted_indices]
                
            individual = np.zeros(self.num_planes)
            for runway in runway_planes:
                num_planes_on_runway = len(runway_planes[runway])
                if num_planes_on_runway > 0:
                    fractional_values = np.linspace(0.1, 0.9, num_planes_on_runway)
                    for idx, plane_idx in enumerate(runway_planes[runway]):
                        individual[plane_idx] = runway + fractional_values[idx]
            
            self.population.append(individual)

    def decode(self, real_array):
        runway_assignment = np.floor(real_array).astype(int)
        fractional_parts = real_array - runway_assignment
        times = np.zeros(self.num_planes)
        
        runway_planes = [[] for _ in range(self.num_runways)]
        for i in range(self.num_planes):
            r_idx = runway_assignment[i] - 1
            runway_planes[r_idx].append((i, fractional_parts[i]))

        for r in range(self.num_runways):
            if len(runway_planes[r]) == 0:
                continue
            runway_planes[r].sort(key=lambda x: x[1])
            from linprog import solve_sequence_with_cost
            sequence = [x[0] for x in runway_planes[r]]
            n = len(sequence)
            a, b, c = self.earliest_landing_times[sequence], self.latest_landing_times[sequence], self.target_landing_times[sequence]
            d, e = self.penalty_early[sequence], self.penalty_late[sequence]
            s = self.separation[sequence][:, sequence]
            time, cost = solve_sequence_with_cost(n, a, b, c, d, e, s)
            if cost != np.inf:
                times[sequence] = time
        return runway_assignment, times

    def evaluate_individual(self, individual):
        runway_assignment, times = self.decode(individual)
        return self.evaluator.compute((runway_assignment, times))

    def explode(self):
        fitness_arr = np.array(self.fitness_values)
        f_min = np.min(fitness_arr)
        f_max = np.max(fitness_arr)
        s_list = []
        a_list = []
        
        for i in range(self.fw_size):
            s_i = self.sp_size * (f_max - self.fitness_values[i] + self.epsilon) / np.sum(f_max - fitness_arr + self.epsilon)
            s_i = int(round(s_i))
            s_i = max(1, min(s_i, self.sp_size))
            s_list.append(s_i)
            a_i = self.init_amps * (self.fitness_values[i] - f_min + self.epsilon) / np.sum(fitness_arr - f_min + self.epsilon)
            a_i = max(0.1, min(a_i, self.init_amps))
            a_list.append(a_i)
        
        self.amps = a_list
        
        sparks = []
        for i in range(self.fw_size):
            base_ind = self.population[i]
            amp = self.amps[i]
            for _ in range(s_list[i]):
                idxs = random.sample(range(self.fw_size), 3)
                while i in idxs:
                    idxs = random.sample(range(self.fw_size), 3)
                
                x1, x2, x3 = self.population[idxs[0]], self.population[idxs[1]], self.population[idxs[2]]
                F = amp / self.init_amps
                mutant = x1 + F * (x2 - x3)
                mutant = np.clip(mutant, 1, self.num_runways + 1 - 1e-5)
                
                trial = base_ind.copy()
                j_rand = random.randint(0, self.num_planes - 1)
                for d in range(self.num_planes):
                    if random.random() < self.mutation_rate or d == j_rand:
                        trial[d] = mutant[d]
                sparks.append(trial)
        
        return sparks

    def mutate(self, sparks):
        gaussian_sparks = []
        for spark in sparks:
            if np.random.rand() < self.mutation_rate:
                new_spark = spark.copy()
                for d in range(self.num_planes):
                    if np.random.rand() < 0.5:
                        noise = np.random.normal(0, 1)
                        new_spark[d] += noise
                        new_spark[d] = np.clip(new_spark[d], 1, self.num_runways + 1 - 1e-5)
                gaussian_sparks.append(new_spark)
        return gaussian_sparks

    def select(self, sparks, gaussian_sparks):
        all_individuals = self.population + sparks + gaussian_sparks
        all_fitness = [self.evaluate_individual(ind) for ind in all_individuals]
        
        new_population = []
        selected_indices = set()
        
        for _ in range(self.fw_size):
            best_idx = None
            best_val = float('inf')
            
            for idx, fit in enumerate(all_fitness):
                if idx in selected_indices:
                    continue
                
                min_dist = float('inf')
                for selected_idx in selected_indices:
                    dist = np.linalg.norm(all_individuals[idx] - all_individuals[selected_idx])
                    min_dist = min(min_dist, dist)
                
                if len(selected_indices) == 0:
                    min_dist = 0
                
                score = fit - min_dist * 0.01
                if score < best_val:
                    best_val = score
                    best_idx = idx
            if best_idx is None:
                best_idx = np.argmin(all_fitness)
            
            selected_indices.add(best_idx)
            new_population.append(all_individuals[best_idx])
        
        # Enhanced crossover mechanism with more optimized blending
        additional_population = []
        for idx in selected_indices:
            parent = all_individuals[idx]
            possible_cross_indices = list(selected_indices - {idx})
            random.shuffle(possible_cross_indices)
            for cross_idx in possible_cross_indices[:2]:  # Selected two distinct parents
                cross_parent = all_individuals[cross_idx]
                crossover_point = random.randint(1, self.num_planes - 1)
                child = np.concatenate((parent[:crossover_point], cross_parent[crossover_point:]))
                additional_population.append(child)
        
        return new_population + additional_population

    def optimize(self):
        best_individual = None
        best_fitness = float('inf')
        imp = 0 
        while not self.evaluator.stop():
            self.fitness_values = [self.evaluate_individual(ind) for ind in self.population]
            current_best = min(self.fitness_values)
            
            if current_best < best_fitness:
                imp = 0
                best_fitness = current_best
                best_individual = self.population[self.fitness_values.index(current_best)]
            else:
                imp += 1
            
            sparks = self.explode()
            gaussian_sparks = self.mutate(sparks)
            self.population = self.select(sparks, gaussian_sparks)

            if imp >= 15:
                break

        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()
