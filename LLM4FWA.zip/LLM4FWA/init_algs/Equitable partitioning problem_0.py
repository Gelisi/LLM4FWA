import numpy as np
import random
import time
import copy

class FWA:
    def __init__(self, evaluator, n, fw_size=50, sp_size=200, 
                 init_amp=2, max_iter=200):
        """
        分组专用烟花算法类（保证x含1~8且仅含1~8）
        
        参数:
            evaluator: 评估函数（输入x返回适应度，x需满足1~8且全出现）
            n: 向量长度（x的长度）
            fw_size: 烟花数量（种群大小）
            sp_size: 总火花数（所有烟花爆炸产生的火花总数）
            init_amp: 初始爆炸幅度（单次爆炸扰动次数）
            max_iter: 最大迭代次数
        """
        self.evaluator = evaluator  # 评估函数接口
        self.n = n                  # 向量长度
        self.fw_size = fw_size      # 烟花数量
        self.sp_size = sp_size      # 总火花数
        self.init_amp = init_amp    # 初始爆炸幅度
        self.max_iter = max_iter    # 最大迭代次数
        
        # 动态参数
        self.amps = [init_amp] * fw_size  # 各烟花爆炸幅度
        self.population = []              # 当前种群
        self.best_solution = None         # 全局最优解
        self.best_fitness = float('inf')  # 全局最优适应度
        self.silent = 0

    def _initialize_population(self):
        """初始化有效种群（保证x含1~8且全出现）"""
        population = []
        required = set(range(1, 9))  # 必须包含的数{1,2,...,8}
        
        for _ in range(self.fw_size):
            # 步骤1：生成包含1~8的基础序列（长度≥8）
            base = list(required)
            random.shuffle(base)  # 随机排列1~8
            
            # 步骤2：填充剩余位置（n>8时）
            if self.n > 8:
                # 从1~8中随机选择剩余元素（允许重复）
                remaining = [random.choice(list(required)) for _ in range(self.n - 8)]
                individual = base + remaining
            else:
                individual = base  # n=8时直接使用排列
            
            population.append(individual)
        
        return population

    def explode(self, firework, num_sparks, amplitude):
        """
        爆炸算子（保证子火花仍含1~8）
        :param firework: 原始烟花（有效向量）
        :param num_sparks: 生成火花数量
        :param amplitude: 扰动强度（交换次数）
        :return: 子火花列表（全部有效）
        """
        sparks = []
        
        for _ in range(num_sparks):
            spark = firework.copy()
            
            # 扰动方式：随机交换amplitude次（不改变元素集合）
            for _ in range(amplitude):
                i, j = random.sample(range(self.n), 2)  # 选两个不同位置
                spark[i], spark[j] = spark[j], spark[i]  # 交换
            
            # 理论上无需检查（原firework有效，交换后仍有效）
            sparks.append(spark)
        
        return sparks

    def mutate(self, sparks, mutation_rate=0.3):
        """
        变异算子（增强多样性且保持有效性）
        :param sparks: 输入火花列表
        :param mutation_rate: 变异概率
        :return: 变异后火花列表（全部有效）
        """
        mutated = []
        
        for spark in sparks:
            if random.random() >= mutation_rate:
                mutated.append(spark.copy())
                continue
                
            new_spark = spark.copy()
            i, j = random.sample(range(self.n), 2)
            new_spark[i], new_spark[j] = new_spark[j], new_spark[i]
            
            mutated.append(new_spark)
        
        return mutated

    def select(self, population, sparks, mutated_sparks):
        """
        选择算子（合并候选解并筛选最优）
        :param population: 当前种群
        :param sparks: 爆炸火花
        :param mutated_sparks: 变异火花
        :return: 下一代种群
        """
        # 合并所有候选解
        candidates = population + sparks + mutated_sparks
        
        # 评估所有候选解
        candidate_fitness = [self.evaluator.compute(c) for c in candidates]
        
        # 按适应度排序（越小越好）
        sorted_pairs = sorted(zip(candidates, candidate_fitness), 
                             key=lambda x: x[1])
        
        # 提取前fw_size个作为下一代
        next_pop = [pair[0] for pair in sorted_pairs[:self.fw_size]]
        
        # 更新全局最优解
        current_best_pair = sorted_pairs[0]
        if current_best_pair[1] < self.best_fitness:
            self.best_fitness = current_best_pair[1]
            self.best_solution = current_best_pair[0].copy()
            self.silent = 0
        else:
            self.silent += 1
        
        return next_pop

    def optimize(self):
        """主优化流程（调用简洁，仅需核心算子）"""
        start_time = time.time()
        self.population = self._initialize_population()
        
        # 初始评估与最优解初始化
        fitness = [self.evaluator.compute(ind) for ind in self.population]
        best_idx = np.argmin(fitness)
        self.best_fitness = fitness[best_idx]
        self.best_solution = self.population[best_idx].copy()

        while not self.evaluator.stop():
            
            if time.time() - start_time > 1200:  
                print("超时终止: 运行时间超过5小时")
                break
            
            # 调整爆炸幅度（可选增强）
            min_fit, max_fit = min(fitness), max(fitness)
            for i in range(self.fw_size):
                # 适应度越好（值越小），幅度越大（增强探索）
                normalized = (fitness[i] - min_fit) / (max_fit - min_fit + 1e-8)
                self.amps[i] = int(self.init_amp * (1 + normalized))  # 1~2倍初始幅度
                self.amps[i] = max(1, min(self.amps[i], self.n))  # 限制幅度范围

            # 生成爆炸火花（按总火花数分配）
            all_sparks = []
            for i in range(self.fw_size):
                sparks_per_fw = self.sp_size // self.fw_size
                if i < self.sp_size % self.fw_size:
                    sparks_per_fw += 1  # 分配剩余火花
                sparks = self.explode(
                    firework=self.population[i],
                    num_sparks=sparks_per_fw,
                    amplitude=self.amps[i]
                )
                all_sparks.extend(sparks)

            # 变异处理
            mutated_sparks = self.mutate(all_sparks, mutation_rate=0.25)

            # 选择下一代
            self.population = self.select(
                population=self.population,
                sparks=all_sparks,
                mutated_sparks=mutated_sparks
            )

            # 评估新一代适应度
            fitness = [self.evaluator.compute(ind) for ind in self.population]
            if self.silent >= 50:
                break
        

        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()