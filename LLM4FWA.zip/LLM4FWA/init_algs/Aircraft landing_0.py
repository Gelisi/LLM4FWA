import random
import numpy as np
from typing import List, Dict, Tuple
import copy
import time
class FWA:
    def __init__(
        self,
        evaluator: callable,  # 评估函数：input -> fitness (越小越好)
        num_planes: int,      # 飞机数量
        num_runways: int,     # 跑道数量
        planes: List[Dict],   # 飞机信息（含"earliest"/"latest"/"target"/"penalty_early"/"penalty_late"）
        separation: List[List[float]],  # 间隔矩阵（separation[i][j] = i早于j的最小间隔）
        fw_size: int = 5,    # 烟花数量（种群大小）
        sp_size: int = 20,   # 总火花数（所有烟花爆炸产生的火花总数）
        init_amp: float = 5,  # 初始爆炸幅度（时间扰动比例，相对于时间窗长度）
        max_iter: int = 200,  # 最大迭代次数
        mutation_rate: float = 0.2,  # 变异概率
    ):
        # 核心参数存储
        self.evaluator = evaluator
        self.num_planes = num_planes
        self.num_runways = num_runways
        self.planes = planes
        self.separation = np.array(separation)
        self.fw_size = fw_size
        self.sp_size = sp_size
        self.init_amps = init_amp
        self.max_iter = max_iter
        self.mutation_rate = mutation_rate
        self.silent = 0
        self.earliest_landing_times = np.array([self.planes[index]["earliest"] for index in range(self.num_planes)])
        self.target_landing_times = np.array([self.planes[index]["target"] for index in range(self.num_planes)])
        self.latest_landing_times = np.array([self.planes[index]["latest"] for index in range(self.num_planes)])
        self.penalty_early = np.array([self.planes[index]['penalty_early'] for index in range(self.num_planes)])
        self.penalty_late = np.array([self.planes[index]['penalty_late'] for index in range(self.num_planes)])
        # 动态参数（爆炸幅度自适应）
        self.amps = [init_amp] * fw_size  # 每个烟花的爆炸幅度
        self.population = []  # 种群存储（元组：(runway_assignment, landing_times)）


    def sequence2time(self, sequence):
        #此处sequence是一个numpy的排序
        import sys
        sys.path.append('/home/spcen/project/LLM4FWA')
        from linprog import solve_sequence_with_cost
        n = self.num_planes
        a, b, c = self.earliest_landing_times[sequence], self.latest_landing_times[sequence], self.target_landing_times[sequence]
        d, e = self.penalty_early[sequence], self.penalty_late[sequence]
        s = self.separation[sequence][:,sequence]
        return solve_sequence_with_cost(n, a, b, c, d, e, s)


    def initialize(self):

        target_landing_times = [self.planes[index]["target"] for index in range(self.num_planes)]
        idx = np.argsort(target_landing_times)
        times, cost = self.squence2time(idx)
        runway_assignment = [1 for i in range(self.num_planes)]
        final_times = [times[idx.tolist().index(k)] for k in range(self.num_planes)]
        return runway_assignment, final_times, idx
    
    def explode(self, firework, amp):
        runway_assignment, times, sequence = firework
        exploded = []
        for k in range(self.sp_size // self.fw_size):
            idx = copy.deepcopy(sequence)
            for kk in range(amp):
                i, j = random.sample(range(self.num_planes), 2)
                idx[i], idx[j] = idx[j], idx[i]
            times, cost = self.sequence2time(idx)
            if  cost != np.inf:
                runway_assignment = [1 for i in range(self.num_planes)]
                final_times = np.array([times[idx.tolist().index(k)] for k in range(self.num_planes)])
                exploded.append((runway_assignment, final_times, idx))
        return exploded

    def mutate(self, sparks: List[Tuple[List[int], List[float]]]) -> List[Tuple[List[int], List[float]]]:
        """变异算子：对火花进行额外扰动"""
        mutated = []
        for spark in sparks:
            runway_assignment, times, sequence = spark
            idx = copy.deepcopy(sequence)
            i, j = random.sample(range(self.num_planes), 2)
            idx[i], idx[j] = idx[j], idx[i]
            times, cost = self.sequence2time(idx)
            if cost != np.inf:
                runway_assignment = [1 for i in range(self.num_planes)]
                final_times = np.array([times[idx.tolist().index(k)] for k in range(self.num_planes)])
                mutated.append((runway_assignment, final_times, idx))
        return mutated

    def select(self, population: List[Tuple[List[int], List[float]]], 
               sparks: List[Tuple[List[int], List[float]]], 
               mutated_sparks: List[Tuple[List[int], List[float]]]) -> List[Tuple[List[int], List[float]]]:
        """选择算子：合并候选解并选择最优种群"""
        # 合并所有候选解
        candidates = population + sparks + mutated_sparks
        
        # 评估适应度（调用用户提供的evaluator）
        candidate_fitness = [self.evaluator.compute((ind[0], ind[1])) for ind in candidates]
        
        # 按适应度排序（越小越好），选择前fw_size个
        sorted_indices = np.argsort(candidate_fitness)
        return [candidates[i] for i in sorted_indices[:self.fw_size]]

    def optimize(self) -> Tuple[List[int], List[float], float]:
        """主优化流程"""
        # 初始化种群（确保所有个体合法）
        self.population = []
        while len(self.population) < self.fw_size:
            runway_assignment, times, idx = self.initialize()
            self.population.append((runway_assignment, times, idx))
        
        best_fitness = float('inf')
        best_individual = None
        
        while not self.evaluator.stop():
            # 评估当前种群适应度
            start_time = time.time()
            fitness = [self.evaluator.compute((ind[0], ind[1])) for ind in self.population]
            current_best_idx = np.argmin(fitness)
            current_best_fit = fitness[current_best_idx]
            current_best_ind = self.population[current_best_idx]
            
            # 更新全局最优
            if current_best_fit < best_fitness:
                best_fitness = current_best_fit
                best_individual = current_best_ind
                self.silent = 0
            else:
                self.silent += 1
            
            # 自适应调整爆炸幅度（适应度越好，幅度越大）
            max_fit = max(fitness)
            self.amps = [
                max(1, min(int(self.init_amps * (1.5 - f/max_fit)), self.fw_size))
                for f in fitness
            ]
            # 生成爆炸火花
            all_sparks = []
            for i in range(self.fw_size):
                sparks = self.explode(self.population[i], self.amps[i])
                all_sparks.extend(sparks)
            
            # 变异处理
            mutated_sparks = self.mutate(all_sparks)
            
            # 选择下一代
            self.population = self.select(self.population, all_sparks, mutated_sparks)
            if self.silent >= 10:
                break
        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()