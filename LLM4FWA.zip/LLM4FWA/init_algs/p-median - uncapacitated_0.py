import numpy as np
import random
import time
class FWA:
    def __init__(self, evaluator, n, p, pop_size=50, max_iter=100, 
                 explosion_amp=2, mutation_prob=0.1):
        """
        初始化烟花算法参数
        
        参数:
            n (int): 0-1 串长度
            p (int): 1 的数量（必须满足 0 < p < n）
            pop_size (int): 种群大小（默认50）
            max_iter (int): 最大迭代次数（默认100）
            explosion_amp (int): 爆炸幅度（控制子代生成数量，默认2）
            mutation_prob (float): 变异概率（默认0.1）
        """
        # 约束检查
        assert 0 < p < n, "p 必须满足 0 < p < n"
        self.n = n
        self.p = p
        self.evaluator = evaluator
        self.pop_size = pop_size
        self.max_iter = max_iter
        self.explosion_amp = explosion_amp  # 每个烟花生成的火花数
        self.mutation_prob = mutation_prob  # 每个火花的变异概率
        self.silent = 0
        
        # 初始化种群和最优解
        self.population = self._initialize_population()
        self.best_solution = None
        self.best_fitness =  np.inf

    def _initialize_population(self):
        """初始化种群：每个个体是长度为n的0-1串，恰好p个1"""
        population = []
        for _ in range(self.pop_size):
            # 随机选择p个位置置1
            ones_pos = random.sample(range(self.n), self.p)
            individual = [0] * self.n
            for pos in ones_pos:
                individual[pos] = 1
            population.append(individual)
        return population

    def explode(self, parent):
        """爆炸操作：生成子代（火花），保持p个1"""
        child = parent.copy()
        # 随机选择爆炸幅度内的位置（不超过种群大小）
        num_sparks = min(self.explosion_amp, self.pop_size)
        for _ in range(num_sparks):
            # 随机选择两个不同的位置，交换0和1（保持1的总数）
            pos1, pos2 = random.sample(range(self.n), 2)
            child[pos1], child[pos2] = child[pos2], child[pos1]
        return child

    def mutate(self, spark):
        """变异操作：随机交换两个位置的值，保持p个1"""
        if random.random() < self.mutation_prob:
            # 随机选择两个不同的位置
            pos1, pos2 = random.sample(range(self.n), 2)
            spark[pos1], spark[pos2] = spark[pos2], spark[pos1]
        return spark

    def select(self, population, fitnesses):
        """选择操作：轮盘赌选择（保留优质个体）"""
        # 计算累积概率
        total_fitness = sum(fitnesses)
        probs = [f / total_fitness for f in fitnesses]
        # 轮盘赌选择
        selected = []
        for _ in range(self.pop_size):
            r = random.random()
            cumulative = 0
            for i, prob in enumerate(probs):
                cumulative += prob
                if cumulative >= r:
                    selected.append(population[i])
                    break
        return selected

    def optimize(self):
        """主优化流程"""
        # 初始化最优解
        initial_fitnesses = [self.evaluator.compute(ind) for ind in self.population]
        best_idx = np.argmax(initial_fitnesses)
        self.best_solution = self.population[best_idx].copy()
        self.best_fitness = initial_fitnesses[best_idx]
        start_time = time.time()
        # 迭代优化
        while not self.evaluator.stop():
            
            if time.time() - start_time > 3600 * 5:  
                print("超时终止: 运行时间超过5小时")
                break
            # 生成所有火花（子代）
            sparks = []
            for parent in self.population:
                # 每个父代生成explosion_amp个子代
                child = self.explode(parent)
                child = self.mutate(child)
                sparks.append(child)
            
            # 合并父代和火花，选择下一代
            combined_pop = self.population + sparks
            combined_fitnesses = [self.evaluator.compute(ind) for ind in combined_pop]
            
            self.population = self.select(combined_pop, combined_fitnesses)
            
            # 更新最优解
            current_best_idx = np.argmin(combined_fitnesses)
            current_best_fitness = combined_fitnesses[current_best_idx]
            if current_best_fitness < self.best_fitness:
                self.silent = 0
                self.best_solution = combined_pop[current_best_idx].copy()
                self.best_fitness = current_best_fitness
            else:
                self.silent += 1
            
            if self.silent >= 50:
                break
            

        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()