import numpy as np
import random
import math
import time
import copy

class FWA:
    def __init__(self, evaluator, distance_matrix, num_cities, 
                 fw_size=10, sp_size=100, init_amp=5, 
                 max_iter=1000000, gm_ratio=0.2):
        """
        初始化参数
        :param distance_matrix: 距离矩阵
        :param num_cities: 城市数量
        :param fw_size: 烟花数量
        :param sp_size: 总火花数量
        :param init_amp: 初始爆炸幅度
        :param max_iter: 最大迭代次数
        :param gm_ratio: 引导变异比例
        """
        self.evaluator = evaluator
        self.dist_mat = distance_matrix
        self.num_cities = num_cities
        self.fw_size = fw_size
        self.sp_size = sp_size
        self.init_amp = init_amp
        self.max_iter = max_iter
        self.gm_ratio = gm_ratio
        self.silent = 0
        # 动态参数
        self.amps = [init_amp] * fw_size  # 爆炸幅度

        
    def _initialize_population(self):
        """初始化烟花种群"""
        population = []
        for _ in range(self.fw_size):
            path = list(range(self.num_cities))
            random.shuffle(path)
            population.append(path)
        return population
    
    def explosion_operator(self, firework, num_sparks, amplitude):
        """
        爆炸算子
        :param firework: 原始烟花路径
        :param num_sparks: 生成火花数量
        :param amplitude: 爆炸幅度（交换次数）
        """
        sparks = []
        for _ in range(num_sparks):
            new_path = firework.copy()
            for _ in range(int(amplitude)):
                i, j = random.sample(range(self.num_cities), 2)
                new_path[i], new_path[j] = new_path[j], new_path[i]
            sparks.append(new_path)
        return sparks
    
    def mutation_operator(self, sparks, mutation_rate=0.3):
        """
        改进的变异算子：结合2-opt局部搜索和自适应反转变异
        :param sparks: 输入火花集合
        :param mutation_rate: 变异概率
        """

        def adaptive_reverse_mutation(path, amplitude):
            """自适应路径反转变异"""
            new_path = path.copy()
            for _ in range(amplitude):
                # 随机选择两个不同位置进行反转
                i, j = sorted(random.sample(range(len(path)), 2))
                new_path[i:j+1] = reversed(new_path[i:j+1])
            return new_path

        def two_opt_mutation(path):
            """2-opt局部搜索变异"""
            best = path
            improved = True
            max_tries = 10  # 限制尝试次数防止过计算
            while improved and max_tries > 0:
                improved = False
                for i in range(1, len(path)-2):
                    for j in range(i+1, len(path)):
                        if j-i == 1: continue
                        # 计算交换后的距离变化
                        old_dist = self.dist_mat[best[i-1]][best[i]] + self.dist_mat[best[j-1]][best[j]]
                        new_dist = self.dist_mat[best[i-1]][best[j-1]] + self.dist_mat[best[i]][best[j]]
                        if new_dist < old_dist:
                            best = best[:i] + best[i:j][::-1] + best[j:]
                            improved = True
                            max_tries -= 1
                            break
                    if improved:
                        break
            return best
        
        mutated = []
        for spark in sparks:
            # 概率决定是否变异
            if random.random() < mutation_rate:
                # 两种变异策略结合
                if random.random() < 0.5:
                    # 策略1：自适应反转变异
                    amp = int(1 + len(spark)*0.1*self.current_amp_ratio)
                    new_spark = adaptive_reverse_mutation(spark, amp)
                else:
                    # 策略2：2-opt局部搜索
                    new_spark = two_opt_mutation(spark)
                mutated.append(new_spark)
            else:
                mutated.append(spark.copy())
        return mutated
    
    def selection_operator(self, population, sparks, mutated):
        """
        选择算子
        :param population: 当前种群
        :param sparks: 爆炸火花
        :param mutated: 变异火花
        """
        # 合并所有候选解
        candidates = population + sparks + mutated
        old_best = copy.deepcopy(self.evaluator.get_best_fitness())
        # 按适应度排序
        candidates.sort(key=lambda x: self.evaluator.compute(x))
        new_best = copy.deepcopy(self.evaluator.get_best_fitness())
        if new_best < old_best - 1e-8:
            self.silent = 0
        else:
            self.silent += 1
        #print(old_best, '------>', new_best, self.silent)
        return candidates[:self.fw_size]
    
    
    def optimize(self):
        """主优化流程"""
        start_time = time.time()  # 记录开始时间
        self.current_amp_ratio = 1.0  
        population = self._initialize_population()
        while not self.evaluator.stop():
            
            if time.time() - start_time > 3600 * 5:  
                print("超时终止: 运行时间超过5小时")
                break
            # 计算适应度
            fitness = [self.evaluator.compute(p) for p in population]
            
            # 自适应调整爆炸参数
            total_sparks = self.sp_size
            # 生成爆炸火花
            all_sparks = []
            for i in range(self.fw_size):

                sparks = self.explosion_operator(
                    population[i], 
                    total_sparks // self.fw_size, 
                    self.amps[i]
                )
                all_sparks.extend(sparks)
                if self.evaluator.compute(sparks[0]) < fitness[i]:
                    self.amps[i] *= 1.2
                else:
                    self.amps[i] *= 0.8

                self.amps[i] = max(self.amps[i] , 1)
                self.amps[i] = min(self.amps[i], self.num_cities)         
        
            
            # 生成变异火花
            mutated_sparks = self.mutation_operator(all_sparks)
            
            # 选择新一代种群
            population = self.selection_operator(
                population, 
                all_sparks, 
                mutated_sparks
            )
            self.current_amp_ratio *= 0.95 
            if self.silent >= 50:
                break
        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()

