import numpy as np
import random
import time
import copy

class FWA:
    def __init__(self, evaluator, n, fw_size=50, sp_size=200, 
                 init_amp=2, max_iter=200, gm_ratio=0.1):
        """
        作业调度专用烟花算法类
        
        参数:
            evaluator: 评估函数
            n: 任务数量（排列长度）
            fw_size: 烟花数量（种群大小）
            sp_size: 总火花数（所有烟花爆炸产生的火花总数）
            init_amp: 初始爆炸幅度（单次爆炸扰动次数）
            max_iter: 最大迭代次数
            gm_ratio: 引导变异比例（本问题暂未使用）
        """
        self.evaluator = evaluator  # 评估函数接口
        self.n = n                  # 任务数
        self.fw_size = fw_size      # 烟花数量
        self.sp_size = sp_size      # 总火花数
        self.init_amp = init_amp    # 初始爆炸幅度
        self.max_iter = max_iter    # 最大迭代次数
        self.gm_ratio = gm_ratio    # 保留参数（本问题未使用）
        
        # 动态参数
        self.amps = [init_amp] * fw_size  # 各烟花爆炸幅度
        self.population = []              # 当前种群
        self.best_solution = None         # 全局最优解
        self.best_fitness = float('inf')  # 全局最优适应度
        self.silent_counter = 0           # 沉默计数器（连续无改进次数）

    def _initialize_population(self):
        """初始化有效排列种群"""
        return [random.sample(range(1, self.n+1), self.n) 
                for _ in range(self.fw_size)]

    def explode(self, firework, num_sparks, amplitude):
        """
        爆炸算子：生成带扰动的子火花
        :param firework: 原始烟花（排列）
        :param num_sparks: 生成火花数量
        :param amplitude: 爆炸幅度（扰动强度）
        :return: 子火花列表
        """
        sparks = []
        for _ in range(num_sparks):
            spark = firework.copy()
            # 按幅度进行多次扰动（交换/逆序/插入）
            for _ in range(amplitude):
                perturb_type = random.choice(['swap', 'invert', 'insert'])
                
                if perturb_type == 'swap':
                    # 单交换扰动
                    i, j = random.sample(range(self.n), 2)
                    spark[i], spark[j] = spark[j], spark[i]
                    
                elif perturb_type == 'invert':
                    # 子序列逆序（长度≥2）
                    if self.n >= 2:
                        start = random.randint(0, self.n-2)
                        end = random.randint(start+1, self.n-1)
                        spark[start:end+1] = spark[start:end+1][::-1]
                        
                elif perturb_type == 'insert':
                    # 元素插入（长度≥2）
                    if self.n >= 2:
                        elem = random.choice(spark)
                        spark.remove(elem)
                        spark.insert(random.randint(0, self.n-1), elem)
            sparks.append(spark)
        return sparks

    def mutate(self, sparks, mutation_rate=0.5):
        """
        变异算子：增强火花多样性
        :param sparks: 输入火花列表
        :param mutation_rate: 变异概率
        :return: 变异后火花列表
        """
        mutated = []
        for spark in sparks:
            if random.random() >= mutation_rate:
                mutated.append(spark.copy())
                continue
                
            # 选择变异策略（双交换/长逆序）
            method = random.choice(['double_swap', 'long_invert'])
            new_spark = spark.copy()
            
            if method == 'double_swap':
                # 两次独立交换
                i1, j1 = random.sample(range(self.n), 2)
                new_spark[i1], new_spark[j1] = new_spark[j1], new_spark[i1]
                i2, j2 = random.sample(range(self.n), 2)
                new_spark[i2], new_spark[j2] = new_spark[j2], new_spark[i2]
                
            elif method == 'long_invert':
                # 长子序列逆序（长度≥3）
                if self.n >= 3:
                    start = random.randint(0, self.n-3)
                    end = random.randint(start+2, self.n-1)
                    new_spark[start:end+1] = new_spark[start:end+1][::-1]
                    
            mutated.append(new_spark)
        return mutated

    def select(self, population, sparks, mutated_sparks):
        """
        选择算子：合并候选解并筛选最优种群
        :param population: 当前种群
        :param sparks: 爆炸火花
        :param mutated_sparks: 变异火花
        :return: 下一代种群
        """
        # 合并所有候选解
        candidates = population + sparks + mutated_sparks
        
        # 评估所有候选解适应度
        candidate_fitness = [self.evaluator.compute(cand) for cand in candidates]
        
        # 按适应度排序（越小越好）
        sorted_pairs = sorted(zip(candidates, candidate_fitness), 
                             key=lambda x: x[1])
        
        # 提取前fw_size个作为下一代
        next_pop = [pair[0] for pair in sorted_pairs[:self.fw_size]]
        
        # 更新全局最优解
        current_best_pair = sorted_pairs[0]
        if current_best_pair[1] < self.best_fitness:
            self.best_fitness = current_best_pair[1]
            self.best_solution = current_best_pair[0].copy()
            self.silent_counter = 0  # 重置沉默计数器
        else:
            self.silent_counter += 1  # 无改进则计数器+1
            
        return next_pop

    def _adjust_amplitudes(self, fitness):
        """
        自适应调整爆炸幅度（核心优化逻辑）
        :param fitness: 当前种群适应度列表
        """
        for i in range(self.fw_size):
            # 适应度越好（值越小）的烟花获得更大爆炸幅度
            relative_fitness = fitness[i] / max(fitness)  # 归一化处理
            self.amps[i] = max(1, min(
                int(self.init_amp * (1.5 - relative_fitness)),  # 1~init_amp*1.5范围
                self.n  # 最大不超过任务数（防止过度扰动）
            ))

    def optimize(self):
        """主优化流程"""
        start_time = time.time()
        self.population = self._initialize_population()
        
        # 初始评估与最优解初始化
        initial_fitness = [self.evaluator.compute(ind) for ind in self.population]
        self.best_fitness = min(initial_fitness)
        self.best_solution = self.population[np.argmin(initial_fitness)].copy()
        self.silent_counter = 0

        while not self.evaluator.stop():
            if time.time() - start_time > 3600 * 5:  
                print("超时终止: 运行时间超过5小时")
                break
                
            # 调整爆炸幅度（基于当前种群适应度）
            self._adjust_amplitudes(fitness=initial_fitness)

            # 生成爆炸火花
            all_sparks = []
            for i in range(self.fw_size):
                # 按总火花数分配每个烟花的火花数量
                sparks_per_fw = self.sp_size // self.fw_size
                if i < self.sp_size % self.fw_size:
                    sparks_per_fw += 1  # 分配剩余火花
                
                # 生成带幅度的爆炸火花
                sparks = self.explode(
                    firework=self.population[i],
                    num_sparks=sparks_per_fw,
                    amplitude=self.amps[i]
                )
                all_sparks.extend(sparks)

            # 变异处理
            mutated_sparks = self.mutate(all_sparks, mutation_rate=0.5)

            # 选择下一代种群
            self.population = self.select(
                population=self.population,
                sparks=all_sparks,
                mutated_sparks=mutated_sparks,
            )

            # 评估新一代适应度
            initial_fitness = [self.evaluator.compute(ind) for ind in self.population]

            # 沉默终止检查（连续50代无改进）
            if self.silent_counter >= 50:
                break
                

        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()