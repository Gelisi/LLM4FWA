import openai  # 或其他LLM库
import litellm
from litellm import completion


def call_llm(question: str, model='Qwen3-32b', reasoning_effort=None) -> str:
    litellm.drop_params = True
    messages = [{"content": question, "role": "user"}]
    #response = completion(model=model, messages=messages, reasoning_effort=reasoning_effort, api_key ="sk-J9n12dWFzw5rr9t72gGRlJs0yPAgBWHMy3BG7ulWiGgvZmCY" , api_base = "https://api.gptplus5.com/v1")
    
    response = completion(model=model, messages=messages, reasoning_effort=reasoning_effort, api_key ="sk-0LVhRPpYQsprnrCeo3b9DK0utda0RX6lCSbHvuCi4UBzRyFN" , api_base = "https://yinli.one/v1")
    return response.choices[0].message.content



def LLM_test_visual(img_path):
    from openai import OpenAI
    client = OpenAI(
        base_url='https://az.gptplus5.com/v1',
        # sk-xxx替换为自己的key
        api_key='sk-7elsb0NiQz05wZYX455336C054214d86B068De3c71417014'
    )
    import base64
    with open(img_path, "rb") as image_file:
        base64_image = base64.b64encode(image_file.read()).decode('utf-8')

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "What's in this image?"},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/png;base64,{base64_image}",
                        }
                    },
                ],
            }
        ],
        max_tokens=300,
    )
    return response.choices[0].message.content


if __name__ == "__main__":
    print(call_llm("hello world!"))