import numpy as np
from scipy.optimize import linprog

def solve_sequence_with_cost(n, a, b, c, d, e, s):
    """
    求解满足约束的序列 t0, t1, ..., t_{n-1}，并最小化目标函数
    
    参数:
    n: 序列长度
    a: 下界列表 [a0, a1, ..., a_{n-1}]
    b: 上界列表 [b0, b1, ..., b_{n-1}]
    c: 目标时间列表 [c0, c1, ..., c_{n-1}]
    d: 提前惩罚系数列表 [d0, d1, ..., d_{n-1}]
    e: 延迟惩罚系数列表 [e0, e1, ..., e_{n-1}]
    s: 分离时间矩阵 s[i][j] 表示 tj - ti >= s[i][j] (j > i)
    
    返回:
    t: 解向量 [t0, t1, ..., t_{n-1}]
    total_cost: 总成本
    """
    # 变量：t0, t1, ..., t_{n-1} 和 辅助变量 u_i, v_i
    # 总变量数 = n (t_i) + n (u_i) + n (v_i) = 3n
    num_vars = 3 * n
    
    # 目标函数系数
    # 目标函数：min sum_i (d_i * u_i + e_i * v_i)
    # 其中 u_i = max(c_i - t_i, 0), v_i = max(t_i - c_i, 0)
    c_obj = np.zeros(num_vars)
    for i in range(n):
        c_obj[n + i] = d[i]  # u_i 的系数
        c_obj[2*n + i] = e[i]  # v_i 的系数
    
    # 约束条件：A_ub * x <= b_ub
    # 1. 分离时间约束：tj - ti >= s[i][j] → ti - tj <= -s[i][j]
    # 2. 辅助变量约束：
    #    u_i >= c_i - t_i → t_i + u_i >= c_i → -t_i - u_i <= -c_i
    #    v_i >= t_i - c_i → -t_i + v_i >= -c_i → t_i - v_i <= c_i
    
    # 计算约束数量
    # 分离时间约束：n*(n-1)//2
    # 辅助变量约束：2n (每个i有2个约束)
    num_constraints = n*(n-1)//2 + 2*n
    
    # 初始化约束矩阵
    A_ub = np.zeros((num_constraints, num_vars))
    b_ub = np.zeros(num_constraints)
    
    constraint_idx = 0
    
    # 1. 添加分离时间约束
    for i in range(n):
        for j in range(i+1, n):
            # 约束：ti - tj <= -s[i][j]
            row = np.zeros(num_vars)
            row[i] = 1   # ti
            row[j] = -1  # -tj
            A_ub[constraint_idx] = row
            b_ub[constraint_idx] = -s[i][j]
            constraint_idx += 1
    
    # 2. 添加辅助变量约束
    for i in range(n):
        # 约束1: u_i >= c_i - t_i → -t_i - u_i <= -c_i
        row1 = np.zeros(num_vars)
        row1[i] = -1      # -t_i
        row1[n + i] = -1  # -u_i
        A_ub[constraint_idx] = row1
        b_ub[constraint_idx] = -c[i]
        constraint_idx += 1
        
        # 约束2: v_i >= t_i - c_i → t_i - v_i <= c_i
        row2 = np.zeros(num_vars)
        row2[i] = 1        # t_i
        row2[2*n + i] = -1 # -v_i
        A_ub[constraint_idx] = row2
        b_ub[constraint_idx] = c[i]
        constraint_idx += 1
    
    # 变量边界
    bounds = []
    # t_i 的边界 [a_i, b_i]
    for i in range(n):
        bounds.append((a[i], b[i]))
    # u_i 的边界 [0, ∞) (因为 u_i = max(c_i - t_i, 0))
    for i in range(n):
        bounds.append((0, None))
    # v_i 的边界 [0, ∞) (因为 v_i = max(t_i - c_i, 0))
    for i in range(n):
        bounds.append((0, None))
    
    # 求解线性规划
    res = linprog(c_obj, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
    
    if res.success:
        t = res.x[:n]  # 提取前n个变量 (t_i)
        u = res.x[n:2*n]  # u_i
        v = res.x[2*n:]  # v_i
        total_cost = np.dot(d, u) + np.dot(e, v)
        return t, total_cost
    else:
        return None, np.inf

# 示例使用
if __name__ == "__main__":
    # 示例数据
    n = 3
    a = [0, 1, 2]    # 下界
    b = [1, 11, 12] # 上界
    c = [5, 6, 7]    # 目标时间
    d = [1, 2, 3]    # 提前惩罚系数
    e = [2, 3, 4]    # 延迟惩罚系数
    s = [
        [0, 1, 1],  # s[0][j] for j>0
        [0, 0, 1],   # s[1][j] for j>1
        [0, 0, 0]    # s[2][j] 无约束
    ]
    print(solve_sequence_with_cost(n, a, b, c, d, e, s))
    