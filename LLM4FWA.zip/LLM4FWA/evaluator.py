import time
import pandas as pd
from typing import Callable
import sys
import numpy as np
import multiprocessing
import time
from multiprocessing import Process, Queue

# 设置超时时间（秒）
TIMEOUT = 300

class FitnessCalculator:
    def __init__(self, f, max_evals):
        self.f = f
        self.call_count = 0
        self.best_fitness = np.inf
        self.best_soluiton =  None
        self.max_evals = max_evals
    

    def compute(self, x):
        ans = self.f(x)
        self.call_count += 1
        if ans < self.best_fitness:
            self.best_soluiton = x
            self.best_fitness = ans
            #print(ans, f"{self.call_count} / {self.max_evals}")
        return ans

    def reset_stats(self):
        """重置统计计数器"""
        self.call_count = 0
        self.best_fitness = np.inf
        self.best_soluiton = None
    
    def stop(self):
        return self.call_count > self.max_evals
    
    def get_best_fitness(self):
        #print(self.best_fitness, f"{self.call_count} / {self.max_evals}")
        return self.best_fitness

    def get_best_solution(self):
        return self.best_soluiton


class Evaluator:
    def __init__(self, dataset_name:str):
        self.dataset_name = dataset_name
        self.path = f"/home/spcen/project/CO-Bench/data/{self.dataset_name}"
        self.run_number = 3
        self.f = None 
        #读问题描述
        with open(f"{self.path}/config.py", 'r') as f:
            content = f.read()
            start_tag = "DESCRIPTION = '''"
            end_tag = "'''"
            if start_tag in content and end_tag in content:
                start_idx = content.index(start_tag) + len(start_tag)
                end_idx = content.index(end_tag, start_idx)
                extracted_str = content[start_idx:end_idx]
                self.description = extracted_str
            else:
                self.description = ''
    
    #利用烟花算法解答问题
    def eval(self, fwa_module):
        if self.dataset_name == 'Travelling salesman problem':
            sys.path.append('/home/spcen/project/CO-Bench/data/Travelling salesman problem')
            from config import load_data, eval_func
            instances_500 = load_data(self.path + '/tsp500_test_concorde.txt')
            instances_1000 = load_data(self.path + '/tsp1000_test_concorde.txt')
            instances_10000 = load_data(self.path + '/tsp10000_test_concorde.txt')
            problems = instances_500
            case_number = 0
            total_results = []
            optimal_scores = {
                'tsp10000_test_concorde.txt': [71.77] * 16,
                'tsp1000_test_concorde.txt': [23.180520881091528, 23.185595820967464, 23.015849671324247, 23.537607117355098,
                                            23.437452128607738, 23.31718378127829, 23.337815853824736, 22.98403971254625,
                                            23.056714372610298, 23.344826856094013, 23.204461510197465, 22.739131293587075,
                                            23.188355412394525, 22.89676721383878, 23.321213972552503, 23.288168535452023,
                                            23.40260594371496, 23.379338976209613, 23.373901670260118, 23.217316627245133,
                                            23.237964507712658, 23.468791280324233, 22.921856962988343, 23.10809259424775,
                                            23.370845238521724, 23.241556219224208, 23.348641855759727, 23.53455701244874,
                                            23.385399569524708, 23.324316152061755, 23.600128423871258, 22.97776918106818,
                                            23.23996887566731, 23.39944035075775, 23.21410580402093, 23.093180229981513,
                                            23.41235476581497, 22.907788976836535, 23.023973448563986, 23.38106742108426,
                                            23.015367118079723, 22.610650093362192, 23.728111421819854, 23.31046641124744,
                                            23.25381246570274, 22.889579599261864, 23.138723098665373, 23.228706227395723,
                                            23.420741250703944, 23.255723604641904, 23.63211466330456, 23.03074201227862,
                                            23.08458884685017, 23.241154659459145, 23.445330799785832, 23.315728497380498,
                                            23.262087203582375, 23.43107533587823, 23.020824065107902, 23.591574572456,
                                            23.01019854749962, 23.006394524552746, 23.117390281951273, 23.06132560795126,
                                            22.899650785646813, 23.17319516968116, 23.229133743009296, 23.187607300641957,
                                            22.83150095703399, 23.158901255572648, 23.298349320155108, 23.364983773246387,
                                            23.265256805650658, 23.73268837357109, 23.07144480109362, 23.202894990560697,
                                            23.34293044019312, 23.027139320724427, 23.005485112127072, 23.16783838686215,
                                            23.505726302417372, 23.002594549857108, 23.50388356372942, 23.147934207287026,
                                            23.149537479144914, 23.20934617772166, 23.591015529376406, 23.04614917635098,
                                            23.253196613627406, 23.608716670166032, 23.313874804840438, 23.14887954791675,
                                            23.261925104915175, 23.283273388936596, 22.869470302805432, 23.28919260955595,
                                            23.291061784892037, 23.26303190269252, 23.43192602385145, 22.992654709729297,
                                            23.53527899384453, 23.040088044723632, 23.165752550718327, 23.346603825959306,
                                            23.21040140495141, 23.346553301777227, 23.192654754892565, 23.30425312678073,
                                            23.03197099577737, 23.33672313379179, 23.209507048094107, 23.33316267340018,
                                            22.832592819311447, 23.47921422142005, 23.29841589882617, 22.79469376239716,
                                            23.437580101042798, 22.90129840984213, 23.377778449705787, 23.152730269355438,
                                            23.179248710299515, 23.150584655373375, 23.303559153530237, 23.567343754278223,
                                            23.14174465613352, 23.236813383632978, 23.178718844944385, 23.114735241004848],
                'tsp500_test_concorde.txt': [16.43849479258626, 16.30760609977988, 16.55368794754589, 17.0916769200107,
                                            16.358815620695264, 16.355575136034258, 16.468449176999673, 16.547487678806803,
                                            16.624118787814286, 16.875851583784797, 16.584382768436186, 16.775629024699168,
                                            16.625112093123217, 16.537041048883633, 16.211908886171635, 16.507889182815646,
                                            16.443711824038594, 16.772997858965947, 16.576148488026003, 16.644182889540385,
                                            16.83104599989968, 16.798687309323867, 16.64786310345603, 16.68678554471238,
                                            16.539765290816586, 16.158516162147357, 16.750957469266986, 16.454327423569975,
                                            16.437695592935125, 16.47266324558099, 16.5807314540603, 16.640030608011333,
                                            16.717644006541413, 16.538629003657803, 16.73424552661684, 16.702691981178777,
                                            16.4488503948912, 16.65158792760706, 16.21441667652796, 16.58894596771913,
                                            16.62425057027662, 16.411010231382186, 16.4198250548815, 16.880314028063836,
                                            16.654445215349824, 16.6703557900618, 16.811423319096434, 16.681548608331166,
                                            16.40538961977731, 16.375709814617032, 16.4755439381876, 16.352299703304702,
                                            16.358345088111275, 16.446260979610017, 16.479360821405024, 16.664705227172075,
                                            16.514514381377964, 16.703418138718607, 16.501081465067912, 16.758043371686597,
                                            16.529838521968927, 16.331302381910483, 16.769035549248624, 16.667247187672565,
                                            16.457565298893492, 16.649335805699657, 16.82614018506712, 16.938244810751787,
                                            16.7896287123959, 16.45162524049444, 16.60657770837926, 16.752028686357416,
                                            16.538134167181376, 16.419856051838476, 17.056640374302344, 16.763628081715684,
                                            16.76853264913112, 16.94949524434479, 16.57562195411809, 16.665389374714852,
                                            16.690740743946513, 16.405456340497622, 16.442597689610583, 16.801813848508267,
                                            16.670030108101063, 16.62938726279957, 16.23649751271661, 16.69571793825944,
                                            16.587558708667046, 16.32450912204972, 16.270614173517753, 16.75899873051874,
                                            16.803321805550524, 16.3602825442514, 16.58252109177151, 16.450516009703893,
                                            16.35900041167487, 16.637551343677693, 16.572893477964705, 16.73275661200808,
                                            16.541081653324518, 16.466516697851265, 17.021310751236744, 16.536183906712942,
                                            16.77678089186245, 16.35713000043851, 16.3183776670553, 16.68224023564231,
                                            16.672341313126555, 16.607714934366197, 16.634734868495503, 16.674511551735357,
                                            16.414641537953482, 16.849240225161548, 16.74452644717401, 16.50467692427514,
                                            16.93072503233582, 16.38341557967758, 16.610910144984917, 16.589115661773096,
                                            16.366818207481515, 16.599226446198887, 16.349609487246365, 16.38083156520364,
                                            16.732343248542644, 16.615639804768033, 16.603236295079725, 16.12821378820771]
            }
            keys = list(optimal_scores.keys())
            for k in range(case_number, case_number + 1):
                problem_fitness_calculator = FitnessCalculator(lambda x:eval_func(nodes = problems[k]['nodes'], \
                                                label_tour = problems[k]["label_tour"], tour = x), 1e6)
                num_cities = len(problems[k]["label_tour"])
                dist_matrix = np.zeros((num_cities, num_cities))
                # 计算所有点对的欧氏距离
                for i in range(num_cities):
                    for j in range(num_cities):
                        dx = problems[k]['nodes'][i][0] - problems[k]['nodes'][j][0]  # x 坐标差值
                        dy = problems[k]['nodes'][i][1] - problems[k]['nodes'][j][1]  # y 坐标差值
                        dist_matrix[i, j] = np.sqrt(dx**2 + dy**2)  # 欧氏距离
                results = []
                for _ in range(self.run_number):
                    problem_fitness_calculator.reset_stats()
                    fwa_instance = fwa_module.FWA(problem_fitness_calculator, dist_matrix, num_cities)  # 每次创建新实例
                    results.append(optimal_scores['tsp500_test_concorde.txt'][k] / fwa_instance.optimize()[1])  # 调用实例方法
                total_results.append(results)
            return np.mean(total_results)
        
        elif self.dataset_name == "p-median - uncapacitated":
            sys.path.append('/home/spcen/project/CO-Bench/data/p-median - uncapacitated')
            from config import load_data, eval_func
            problems = [load_data(self.path + f'/pmed{i}.txt') for i in range(1,41)]
            optimal_scores = {
                "pmed1.txt": [5819],
                "pmed2.txt": [4093],
                "pmed3.txt": [4250],
                "pmed4.txt": [3034],
                "pmed5.txt": [1355],
                "pmed6.txt": [7824],
                "pmed7.txt": [5631],
                "pmed8.txt": [4445],
                "pmed9.txt": [2734],
                "pmed10.txt": [1255],
                "pmed11.txt": [7696],
                "pmed12.txt": [6634],
                "pmed13.txt": [4374],
                "pmed14.txt": [2968],
                "pmed15.txt": [1729],
                "pmed16.txt": [8162],
                "pmed17.txt": [6999],
                "pmed18.txt": [4809],
                "pmed19.txt": [2845],
                "pmed20.txt": [1789],
                "pmed21.txt": [9138],
                "pmed22.txt": [8579],
                "pmed23.txt": [4619],
                "pmed24.txt": [2961],
                "pmed25.txt": [1828],
                "pmed26.txt": [9917],
                "pmed27.txt": [8307],
                "pmed28.txt": [4498],
                "pmed29.txt": [3033],
                "pmed30.txt": [1989],
                "pmed31.txt": [10086],
                "pmed32.txt": [9297],
                "pmed33.txt": [4700],
                "pmed34.txt": [3013],
                "pmed35.txt": [10400],
                "pmed36.txt": [9934],
                "pmed37.txt": [5057],
                "pmed38.txt": [11060],
                "pmed39.txt": [9423],
                "pmed40.txt": [5128]
            }
            keys = list(optimal_scores.keys())
            #这边要选择问题实例
            case_number = 18
            total_results = []
            for k in range(19):
                n, m, p, dist = problems[k][0]["n"], problems[k][0]["m"], problems[k][0]["p"], problems[k][0]["dist"]
                problem_fitness_calculator = FitnessCalculator(lambda x:eval_func(n = n, p = p, dist = dist, medians = [i + 1 for i, val in enumerate(x) if val == 1]), 1e6)
                results = []
                for _ in range(self.run_number):
                    problem_fitness_calculator.reset_stats()
                    #fwa_instance = fwa_module.FWA(evaluator = problem_fitness_calculator, n = n, p = p)  # 每次创建新实例
                    fwa_instance = fwa_module.DE(evaluator = problem_fitness_calculator, n = n, p = p)  # 每次创建新实例
                    results.append(optimal_scores[keys[k]][0] / fwa_instance.optimize()[1])  # 调用实例方法
                total_results.append(results)
            print(np.mean(total_results, axis = 1))
            return np.mean(total_results)
        elif self.dataset_name == "Common due date scheduling":
            sys.path.append('/home/spcen/project/CO-Bench/data/Common due date scheduling')
            from config import load_data, eval_func           
            schs = [load_data(self.path + f'/sch{x}.txt') for x in [10, 20, 50, 100, 200, 500, 1000]]
            problems = schs[0] #10D
            optimal_scores = {
                10: [841, 615, 793, 815, 521, 755, 1101, 610, 582, 710],
                20: [2986, 3260, 3600, 3336, 2206, 3016, 4175, 1638, 1992, 2116],
                50: [17990, 14231, 16497, 14105, 14650, 14251, 17715, 21367, 14298, 14377],
                100: [72019, 59351, 68537, 69231, 55291, 62519, 62213, 80844, 58771, 61419],
                200: [254268, 266028, 254647, 297269, 260455, 236160, 247555, 225572, 255029, 269236],
                500: [1581233, 1715332, 1644947, 1640942, 1468325, 1413345, 1634912, 1542090, 1684055, 1520515],
                1000: [6411581, 6112598, 5985538, 6096729, 6348242, 6082142, 6575879, 6069658, 6188416, 6147295],
            }
            keys = list(optimal_scores.keys())
            total_results = []
            case_number = 1
            for k in range(case_number, case_number + 1):
                jobs, h = problems[k]["jobs"], problems[k]['h']
                problem_fitness_calculator = FitnessCalculator(lambda x:eval_func(jobs = jobs, schedule = x), 1e6)
                results = []
                for _ in range(self.run_number):
                    problem_fitness_calculator.reset_stats()
                    fwa_instance = fwa_module.FWA(evaluator = problem_fitness_calculator, jobs = jobs, n = len(jobs))  # 每次创建新实例
                    results.append(optimal_scores[keys[0]][k] / fwa_instance.optimize()[1])  # 调用实例方法
                total_results.append(results)
            return np.mean(total_results)

        elif self.dataset_name == "Equitable partitioning problem":
            sys.path.append('/home/spcen/project/CO-Bench/data/Equitable partitioning problem')
            from config import load_data, eval_func           
            problems = [load_data(self.path + f'/eppperf{i}.txt') for i in [1,2,3,4,5]] + [load_data(self.path + f'/epprandom{i}.txt') for i in [1,2,3,4,5]]
            case_number = 3
            total_results = []
            optimal_scores = {
                "eppperf1.txt": [0],
                "eppperf2.txt": [0],
                "eppperf3.txt": [0],
                "eppperf4.txt": [0],
                "eppperf5.txt": [0],
                "epprandom1.txt": [11.5],
                "epprandom2.txt": [12.75],
                "epprandom3.txt": [13.75],
                "epprandom4.txt": [14.50],
                "epprandom5.txt": [16.25],
            }
            keys = list(optimal_scores.keys())
            for k in range(case_number, case_number + 1):
                data = problems[k][0]["data"]
                problem_fitness_calculator = FitnessCalculator(lambda x:eval_func(data = data, assignment = x), 1e6)
                results = []
                for _ in range(self.run_number):
                    problem_fitness_calculator.reset_stats()
                    #fwa_instance = fwa_module.PSO(evaluator = problem_fitness_calculator, n = len(data))
                    #fwa_instance = fwa_module.DE(evaluator = problem_fitness_calculator, n = len(data))
                    fwa_instance = fwa_module.FWA(evaluator = problem_fitness_calculator, n = len(data))  # 每次创建新实例
                    solution, fitness = fwa_instance.optimize()
                    if optimal_scores[keys[k]][0] == 0:
                        results.append((optimal_scores[keys[k]][0] + 1) / (fitness + 1))
                    else:
                        results.append(optimal_scores[keys[k]][0] / fitness)  # 调用实例方法
                total_results.append(results)
            print(np.mean(total_results, axis = 1))
            return np.mean(total_results)
        
        elif self.dataset_name == "Aircraft landing":
            sys.path.append('/home/spcen/project/CO-Bench/data/Aircraft landing')
            from config import load_data, eval_func           
            all_problems = [load_data(self.path + f'/airland{i}.txt') for i in range(1, 14)] 
            #print(len(problems))
            #做single的
            optimal_scores = {
                "airland1.txt": [700, 90, 0],
                "airland2.txt": [1480, 210, 0],
                "airland3.txt": [820, 60, 0],
                "airland4.txt": [2520, 640, 130, 0],
                "airland5.txt": [3100, 650, 170, 0],
                "airland6.txt": [24442, 554, 0],
                "airland7.txt": [1550, 0],
                "airland8.txt": [1950, 135, 0],
                "airland9.txt": [7848.42, 573.25, 88.72, 0.0],
                "airland10.txt": [17726.06, 1372.21, 246.15, 34.22, 0.0],
                "airland11.txt": [19327.45, 1683.75, 333.53, 69.66, 0.0],
                "airland12.txt": [2549.24, 2204.96, 430.5, 2.86, 0.0],
                "airland13.txt": [58392.69, 4897.92, 821.82, 123.3, 0.0],
            }
            keys = list(optimal_scores.keys())
            total_results = []
            case_number = 10
            for k in range(0, min(1,len(optimal_scores[keys[case_number]]))):
                #print(f"Airplane landing {case_number + 1}, Problem {k + 1}")
                problems = all_problems[case_number]
                num_planes, num_runways, freeze_time, planes, separation = problems[k]["num_planes"], problems[k]["num_runways"], problems[k]["freeze_time"], problems[k]["planes"], problems[k]["separation"]
                problem_fitness_calculator = FitnessCalculator(lambda x:eval_func(num_planes = num_planes, num_runways = num_runways, planes = planes, separation = separation, schedule = {i:{"landing_time":x[1][i-1], "runway":x[0][i-1]} for i in range(1, num_planes + 1)}), 1e6)
                results = []
                for _ in range(self.run_number):
                    problem_fitness_calculator.reset_stats()
                    fwa_instance = fwa_module.FWA(evaluator = problem_fitness_calculator, num_planes = num_planes, num_runways = num_runways, planes = planes, separation = separation)  # 每次创建新实例
                    #fwa_instance = fwa_module.DE(evaluator = problem_fitness_calculator, num_planes = num_planes, num_runways = num_runways, planes = planes, separation = separation)  # 每次创建新实例
                    solution, fitness = fwa_instance.optimize()
                    if np.abs(optimal_scores[keys[case_number]][k]) < 1e-8:
                        results.append((optimal_scores[keys[case_number]][k] + 1) / (fitness + 1))
                    else:
                        results.append(optimal_scores[keys[case_number]][k] / fitness)
                total_results.append(results)
                print(np.mean(results), np.max(results), np.min(results))
            return np.max(total_results)
        
        elif self.dataset_name == "Flow shop scheduling":
            sys.path.append('/home/spcen/project/CO-Bench/data/Flow shop scheduling')
            from config import load_data, eval_func           
            all_problems = [load_data(self.path + f'/tai{i}_{j}.txt') for i in [20, 50, 100] for j in [5, 10, 20]] 
            problems = all_problems[0]
            case_number = 9
            total_results = []
            #for k in range(case_number, case_number + 1):
            for k in range(len(problems)):
                n, m, matrix, ub, lb = problems[k]['n'], problems[k]['m'], problems[k]['matrix'], problems[k]['upper_bound'], problems[k]['lower_bound']
                #print(n, m ,matrix)
                problem_fitness_calculator = FitnessCalculator(lambda x:eval_func(n = n, m = m, matrix = matrix, lower_bound = lb, job_sequence = x), 1e6)
                results = []
                for _ in range(self.run_number):
                    problem_fitness_calculator.reset_stats()
                    #fwa_instance = fwa_module.FWA(evaluator = problem_fitness_calculator, n = n)  # 每次创建新实例
                    #fwa_instance = fwa_module.PSO(evaluator = problem_fitness_calculator, n = n)  # 每次创建新实例
                    fwa_instance = fwa_module.DE(evaluator = problem_fitness_calculator, n = n)  # 每次创建新实例
                    solution, fitness = fwa_instance.optimize()
                    def run_optimize(queue):
                        try:
                            solution, fitness = fwa_instance.optimize()
                            queue.put((solution, fitness, None))
                        except Exception as e:
                            queue.put((None, np.inf, e))

                    def timeout_fn(timeout_duration=600, default=None):
                        queue = Queue()
                        p = Process(target=run_optimize, args=(queue,))
                        p.start()
                        p.join(timeout_duration)
                        
                        if p.is_alive():
                            p.terminate()  # 强制终止进程
                            p.join()
                            solution, fitness = problem_fitness_calculator.get_best_solution(), problem_fitness_calculator.get_best_fitness()
                            return solution, fitness
                        else:
                            solution, fitness, error = queue.get()
                            return solution, fitness
                    
                    solution, fitness = timeout_fn()
                    results.append(lb / fitness)  # 调用实例方法
                total_results.append(results)
            print(np.mean(total_results, axis= 1))
            return np.mean(total_results)



        #TODO other problems

if __name__ == "__main__":
    import sys  # 提前导入sys模块
    
    # 检查是否提供了命令行参数
    if len(sys.argv) < 2:
        print("错误：请提供问题名称作为参数。用法：python xxx.py <问题名称>")
        sys.exit(1)  # 无参数时退出程序
    
    # 从命令行参数获取问题名称（第一个参数）
    problem_name = sys.argv[1]
    
    # 使用问题名称初始化Evaluator
    e = Evaluator(problem_name)
    
    # 动态拼接模块路径（假设模块文件名与问题名称一致）
    module_path = f'/home/spcen/project/LLM4FWA/init_algs/{problem_name}_0.py'
    
    # 加载模块（确保路径已添加到sys.path）
    sys.path.append('/home/spcen/project/LLM4FWA')
    from utils import load_module
    fwa_module = load_module('fwa', module_path)
    
    # 执行评估并输出结果
    print(e.eval(fwa_module))
