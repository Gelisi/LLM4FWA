
def get_crossover_prompts(problem_description, current_codes, current_perfomances):
    introduction = f"You are a seasoned expert in combinatorial optimization and advanced firework algorithms, faced with the challenge of: {problem_description}.\n"
    current_fwa = f"I will present two existing firework algorithms aimed at solving this problem. The first algorithm is as follows: {current_codes[0]}, achieving a performance score of {current_perfomances[0]}; the second algorithm is: {current_codes[1]}, with a performance score of {current_perfomances[1]}. Remember, in this context, a higher performance score indicates a more effective algorithm.\n" 
    requirements = "1. Your task is to intelligently combine the components within the 'explode', 'mutate', and 'select' functions from the provided codes to produce a more efficient firework algorithm.\n" \
                 + "2. Ensure that the input and output signature remains unchanged, but do not modify any other functions.\n" \
                 + "3. Please return the complete firework algorithm code wrapped in the format: <code>xxx</code>, without any additional explanations."
    prompt_crossover = introduction + current_fwa + requirements
    return prompt_crossover
