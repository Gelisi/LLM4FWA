
def get_mutation_prompts(problem_description, current_code, current_perfomance):
    introduction = f"You are a highly skilled expert in combinatorial optimization and firework algorithms, tasked with enhancing a promising solution. Below is the problem: {problem_description}.\n"
    current_fwa = f"I present to you a specific firework algorithm designed to tackle this issue: {current_code}. Its current performance metric is {current_perfomance}. Remember, higher performance indicates a better solution.\n"
    requirements = "1. Select one function from 'explode', 'mutate', or 'select' in the existing code, and revamp it with your innovative design.\n" \
                   + "2. Ensure that your redesign maintains the same input and output structure as the original function, and refrain from altering any other parts of the code.\n" \
                   + "3. Return only the full modified firework algorithm code in the format: <code>xxx</code>, and do not include any explanations."
    prompt_mutation = introduction + current_fwa + requirements
    return prompt_mutation
