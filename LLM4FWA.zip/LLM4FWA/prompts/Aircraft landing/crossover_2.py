
def get_crossover_prompts(problem_description, current_codes, current_perfomances):
    introduction = f"You are a highly skilled expert in combinatorial optimization and firework algorithms. Your task is to tackle the following complex problem: {problem_description}.\n"
    current_fwa = f"I will present two existing firework algorithms aimed at solving this problem. The first algorithm code is: {current_codes[0]} with a performance score of {current_perfomances[0]}. The second algorithm code is: {current_codes[1]} with a performance score of {current_perfomances[1]}. Remember, a higher performance score indicates a better algorithm.\n" 
    requirements = "1. Your objective is to intelligently combine elements from the 'explode', 'mutate', and 'select' functions of both algorithms to design a more powerful solution.\n" \
                 + "2. Ensure that the input and output of the algorithm remain unchanged, but you are free to optimize and enhance the specified functions.\n" \
                 + "3. Please return only the complete code of the enhanced firework algorithm encapsulated in the format: <code>xxx</code>. Do not include any explanations or additional commentary."
    prompt_crossover = introduction + current_fwa + requirements
    return prompt_crossover
