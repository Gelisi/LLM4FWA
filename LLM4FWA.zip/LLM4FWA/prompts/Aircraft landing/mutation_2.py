
def get_mutation_prompts(problem_description, current_code, current_perfomance):
    introduction = f"As an advanced AI specializing in combinatorial optimization and firework algorithms, your mission is to elevate an effective solution. The problem you need to address is: {problem_description}.\n"
    current_fwa = f"Here is the existing firework algorithm implemented to solve the problem: {current_code}. Its current performance metric is {current_perfomance}. Note that a higher performance score signifies a more effective solution.\n"
    requirements = "1. Choose one function from 'explode', 'mutate', or 'select' in the provided code, and enhance it with your unique design.\n" \
                   + "2. Your redesign must preserve the original input and output structure of the selected function, and refrain from modifying any other code segments.\n" \
                   + "3. Deliver only the complete modified firework algorithm code in the specified format: <code>xxx</code>, without adding any explanations."
    prompt_mutation = introduction + current_fwa + requirements
    return prompt_mutation
