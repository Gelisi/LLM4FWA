import sys
import os
import time
from datetime import datetime
from utils import create_output_dir, load_module, copy_file, read_file, choose
import Config
from llm import call_llm
from evaluator import Evaluator
import re
import numpy as np
import sys
sys.path.append('/home/spcen/project/LLM4FWA')
#得到新的算法
def get_algorithm(prompt, dataset_name, gen):
    code, fwa_module = None, None
    try:
        code = call_llm(prompt)
        code = code.split('</code>')[0].split('<code>')[-1]
        if "```python" in code:
            code = code.split("```python")[-1].split("```")[0]
        #print(code)
    except:
        return None, None
    try:
        with open(f'./algorithms/{dataset_name}/{dataset_name}_{gen}.py', 'w') as f:
            f.write(code)
    except:
        return None, None
    try:
        fwa_module = load_module('fwa', f'./algorithms/{dataset_name}/{dataset_name}_{gen}.py')
    except:
        return None, None
    #print(code == None, fwa_module == None)
    return code, fwa_module

def get_prompt(old_prompt, dataset_name, gen):
    newprompt, prompt_module = None, None
    prompt4prompt =  f"You are an expert in prompt engineer. I have a function for generating prompt below:{old_prompt}, please help me to make it more powerful and appropriate for automatic algorithm design\n" \
                    + "You can only modify the 'introduction', 'current_fwa', and 'requirements' fields, not the input and output of the function, and make sure that this prompt allows the large language model to put the returned code in <code>xxx</code> for easy parsing\n" \
                    + f"Only return the code of the function for generating the prompt in <prompt>xxx</prompt>. Do not explain anything"
    try:
        newprompt = call_llm(prompt4prompt)
        newprompt = newprompt.split('</prompt>')[0].split('<prompt>')[-1]
        if "```python" in newprompt:
            newprompt = newprompt.split("```python")[-1].split("```")[0]
    except:
        return None, None
    try:
        if "mutation" in old_prompt:
            with open(f'./prompts/{dataset_name}/mutation_{gen}.py', 'w') as f:
                f.write(newprompt)
            prompt_module = load_module('get_mutation_prompts',f'./prompts/{dataset_name}/mutation_{gen}.py')

        elif "crossover" in old_prompt:
            with open(f'./prompts/{dataset_name}/crossover_{gen}.py', 'w') as f:
                f.write(newprompt)
            prompt_module = load_module('get_crossover_prompts',f'./prompts/{dataset_name}/crossover_{gen}.py')
    except:
        return None, None
    return newprompt, prompt_module

        

def optimize_fwa(dataset_name: str):
    """
    主优化函数：接受数据集名称，执行优化流程
    """
    alg_gen, prompts_gen = 0, [0, 0]
    # 创建独立输出目录
    output_dir_1 = create_output_dir('./algorithms', dataset_name)
    output_dir_2 = create_output_dir('./prompts', dataset_name)
    print(output_dir_1, output_dir_2)
    # 复制初始化算法/提示词
    target_path_1 = copy_file("./init_algs", output_dir_1, f"{dataset_name}_{alg_gen}.py")
    target_path_2 = copy_file("./init_prompts", output_dir_2, f"mutation_{prompts_gen[0]}.py")
    target_path_3 = copy_file("./init_prompts", output_dir_2, f"crossover_{prompts_gen[1]}.py")
    
    # TODO 加载数据集, 评估函数，等等
    eval_func = Evaluator(dataset_name)
    

    # Pool中的元素格式(string, performance, gen)
    mutation_prompts_pool = []
    crossover_prompts_pool = []
    algorithms_pool = []

    # 初始化算法/提示词阶段
    init_code = read_file(target_path_1)
    init_fwa_module = load_module('fwa', target_path_1)
    init_mutation_module = load_module('get_mutation_prompts', target_path_2)
    init_crossover_module = load_module('get_crossover_prompts', target_path_3)

    #评估初始算法
    init_performance = eval_func.eval(init_fwa_module)
    algorithms_pool.append((init_code, init_performance, alg_gen))
    print(f"initial performance:{init_performance}")
    #print((init_code, init_performance, alg_gen))

    #评估初始提示词
    mutation_prompts_pool.append([init_mutation_module, 0, prompts_gen[0]])
    crossover_prompts_pool.append([init_crossover_module, 0, prompts_gen[1]])

    #优化循环
    for i in range(Config.max_iteration):
        print(f"Current best FWAs for {dataset_name}, iter:{i}/{Config.max_iteration}")
        for alg in algorithms_pool:
            print(f"performance : {alg[1]}, from alg_gen: {alg[2]}")
        #mutation
        for j in range(Config.max_try):
            try:
                alg_indexs = choose(algorithms_pool, 1)
                parents = [algorithms_pool[i] for i in alg_indexs]
                current_codes = [parent[0] for parent in parents] 
                current_perfomances = [parent[1] for parent in parents]

                prompts_indexs = choose(mutation_prompts_pool, 1)
                mutation_module = mutation_prompts_pool[prompts_indexs[0]][0]
                mutation_prompt = mutation_module.get_mutation_prompts(eval_func.description, current_codes, current_perfomances)
                code, fwa_module = get_algorithm(mutation_prompt, dataset_name, alg_gen + 1)
                if code != None and fwa_module != None:
                    performance = eval_func.eval(fwa_module)
                algorithms_pool.append((code, performance, alg_gen + 1))
                #print((code, performance, alg_gen + 1))
                alg_gen += 1
                print("mutation success: current try number is %s, current performance is %s, from alg_gen : %s, from prompt_gen: %s"%(j, performance, alg_gen, mutation_prompts_pool[prompts_indexs[0]][-1]))
                break
            except:
                print("mutation fail: current try number is %s"%(j))
                continue

        #crossover
        for j in range(Config.max_try):
            try:
                alg_indexs = choose(algorithms_pool, 2)
                parents = [algorithms_pool[i] for i in alg_indexs]
                current_codes = [parent[0] for parent in parents] 
                current_perfomances = [parent[1] for parent in parents]

                prompts_indexs = choose(crossover_prompts_pool, 1)
                crossover_module = crossover_prompts_pool[prompts_indexs[0]][0]
                crossover_prompt = crossover_module.get_crossover_prompts(eval_func.description, current_codes, current_perfomances)
                code, fwa_module = get_algorithm(crossover_prompt, dataset_name, alg_gen + 1)
                if code != None and fwa_module != None:
                    performance = eval_func.eval(fwa_module)
                algorithms_pool.append((code, performance, alg_gen + 1))
                #print((code, performance, alg_gen + 1))
                alg_gen += 1
                print("crossover success: current try number is %s, current performance is %s, from alg_gen : %s, from prompt_gen: %s"%(j, performance, alg_gen, crossover_prompts_pool[prompts_indexs[0]][-1]))
                break
            except:
                print("crossover fail: current try number is %s"%(j))
                continue
        

        #entropy
        



        algorithms_pool.sort(key = lambda x:x[1], reverse = True)
        algorithms_pool = algorithms_pool[:Config.pop_size]

        #TODO upate prompts pool
        if i % Config.prompts_update_freq == 0 and i >= 3:
            #mutation
            for j in range(min(Config.prompt_size, len(mutation_prompts_pool))):
                mutation_module, mutation_prompt_perfomance, mutation_prompt_gen = mutation_prompts_pool[j]
                score = 0
                success = 0
                for k in range(Config.prompt_eval):
                    try:
                        alg_indexs = choose(algorithms_pool, 1)
                        parents = [algorithms_pool[i] for i in alg_indexs]
                        current_codes = [parent[0] for parent in parents] 
                        current_perfomances = [parent[1] for parent in parents]

                        mutation_prompt = mutation_module.get_mutation_prompts(eval_func.description, current_codes, current_perfomances)
                        code, fwa_module = get_algorithm(mutation_prompt, dataset_name, alg_gen + 1)
                        if code != None and fwa_module != None:
                            performance = eval_func.eval(fwa_module)
                        algorithms_pool.append((code, performance, alg_gen + 1))
                        alg_gen += 1
                        print("Mutation prompt gen: %s update: current performance is %s, from alg_gen : %s"%(mutation_prompts_pool[j][-1], performance, alg_gen))
                        score += (performance - np.mean(current_perfomances))
                        success += 1
                    except:
                        continue
                try:
                    mutation_prompts_pool[j][1] = (score * 1.0) / (success) 
                except:
                    mutation_prompts_pool[j][1] = 0
                print(f"The {j} th mutation prompts, gen:{mutation_prompts_pool[j][-1]}, score:{mutation_prompts_pool[j][1]}")
            
            mutation_prompts_pool.sort(key = lambda x:x[1], reverse = True)
            mutation_prompts_pool = mutation_prompts_pool[:Config.prompt_size]
            with open(f'./prompts/{dataset_name}/mutation_{mutation_prompts_pool[0][-1]}.py', 'r') as f:
                old_prompt = f.read()
            newprompt, mutation_module = get_prompt(old_prompt, dataset_name, prompts_gen[0] + 1)
            mutation_prompts_pool.append([mutation_module, 1.0, prompts_gen[0] + 1])
            print(f"new mutation prompt gen {prompts_gen[0] + 1} is produced")
            prompts_gen[0] += 1


            #crossover
            for j in range(min(Config.prompt_size, len(crossover_prompts_pool))):
                crossover_module, crossover_prompt_perfomance, crossover_prompt_gen = crossover_prompts_pool[j]
                score = 0
                success = 0
                for k in range(Config.prompt_eval):
                    try:
                        alg_indexs = choose(algorithms_pool, 2)
                        parents = [algorithms_pool[alg_index] for alg_index in alg_indexs]
                        current_codes = [parent[0] for parent in parents] 
                        current_perfomances = [parent[1] for parent in parents]

                        crossover_prompt = crossover_module.get_crossover_prompts(eval_func.description, current_codes, current_perfomances)
                        code, fwa_module = get_algorithm(crossover_prompt, dataset_name, alg_gen + 1)
                        if code != None and fwa_module != None:
                            performance = eval_func.eval(fwa_module)
                        algorithms_pool.append((code, performance, alg_gen + 1))
                        alg_gen += 1
                        print("Crossover prompt gen: %s update: current performance is %s, from alg_gen : %s"%(crossover_prompts_pool[j][-1], performance, alg_gen))
                        score += (performance - np.mean(current_perfomances))
                        success += 1
                    except:
                        continue
                try:
                    crossover_prompts_pool[j][1] = (score * 1.0) / (success) 
                except:
                    crossover_prompts_pool[j][1] = 0
                print(f"The {j} th crossover prompts, gen:{crossover_prompts_pool[j][-1]}, score:{crossover_prompts_pool[j][1]}")
            
            crossover_prompts_pool.sort(key = lambda x:x[1], reverse = True)
            crossover_prompts_pool = crossover_prompts_pool[:Config.prompt_size]
            with open(f'./prompts/{dataset_name}/crossover_{crossover_prompts_pool[0][-1]}.py', 'r') as f:
                old_prompt = f.read()
            newprompt, crossover_module = get_prompt(old_prompt, dataset_name, prompts_gen[1] + 1)
            crossover_prompts_pool.append([crossover_module, 1.0, prompts_gen[1] + 1])
            print(f"new crossover prompt gen {prompts_gen[1] + 1} is produced")
            prompts_gen[1] += 1

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python main.py <dataset_name>")
        sys.exit(1)
    
    optimize_fwa(sys.argv[1])
    print("done!")