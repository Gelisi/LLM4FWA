max_iteration = 200
max_try = 5
pop_size = 5


prompts_update_freq = 5
prompt_size = 2
prompt_eval = 5
