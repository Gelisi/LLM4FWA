import os
import importlib.util
import shutil
import random
import numpy as np


def create_output_dir(dataset_name: str, mode: str, clear_existing: bool = True) -> str:
    """创建独立输出目录，可选择清空已存在目录的内容
    
    Args:
        dataset_name: 数据集名称
        mode: 模式（如 'train', 'test'等）
        clear_existing: 如果目录已存在，是否清空内容
    
    Returns:
        创建的目录路径
    """
    dir_name = f"{dataset_name}"
    path = os.path.join(dir_name, mode)
    
    if os.path.exists(path):
        if clear_existing:
            # 清空目录内容但保留目录本身
            for filename in os.listdir(path):
                file_path = os.path.join(path, filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                except Exception as e:
                    print(f'Failed to delete {file_path}. Reason: {e}')
            print(f"Cleared existing directory: {path}")
        else:
            print(f"Directory already exists: {path}")
    else:
        os.makedirs(path)
        print(f"Created output directory: {path}")
    
    return path


def copy_file(source_dir, target_dir, filename):
    """
    将指定目录下的文件复制到另一个目录
    
    参数:
    source_dir -- 源文件所在的目录
    target_dir -- 目标目录
    filename -- 要复制的文件名
    
    返回:
    新文件的完整路径
    """
    # 构建完整的源文件路径
    source_path = os.path.join(source_dir, filename)
    
    # 确保目标目录存在
    os.makedirs(target_dir, exist_ok=True)
    
    # 构建目标文件路径
    target_path = os.path.join(target_dir, filename)
    
    # 执行文件复制
    shutil.copy2(source_path, target_path)
    print(f"文件已复制: {source_path} → {target_path}")
    return target_path

def read_file(file_path):
    """读取整个文件内容并返回字符串"""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    except FileNotFoundError:
        print(f"错误：文件 {file_path} 不存在")
        return None
    except Exception as e:
        print(f"读取文件时出错: {str(e)}")
        return None


def load_module(module_name: str, file_path: str):
    """动态加载Python模块"""
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None:
        raise ImportError(f"Could not load {file_path}")
    
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module



def choose(algorithms_pool, number):
    """
    按照排名概率选择指定数量的算法索引
    
    参数:
    algorithms_pool - 包含(算法, 表现)的元组列表
    number - 需要选择的算法数量
    
    返回:
    按排名概率选择的number个算法索引列表
    """
    # 按表现降序排序算法池
    sorted_indices = sorted(range(len(algorithms_pool)), 
                           key=lambda i: algorithms_pool[i][1], 
                           reverse=True)
    
    n = len(algorithms_pool)
    # 计算基于排名的选择概率
    # 概率公式：P(i) = (n - rank(i) + 1) / sum(1->n)
    # 排名第一(rank=0)的概率最高，排名最后的概率最低
    probabilities = [ (n - rank) / (n * (n + 1) / 2) for rank in range(n) ]
    
    # 准备原始索引和对应概率的映射
    index_probs = []
    for sorted_idx, rank in enumerate(sorted_indices):
        # 原始索引对应的概率
        index_probs.append((rank, probabilities[sorted_idx]))
    
    # 按概率选择指定数量的索引（有放回抽样）
    selected_indices = random.choices(
        [idx for idx, _ in index_probs],
        weights=[prob for _, prob in index_probs],
        k=number
    )
    
    return selected_indices

if __name__ == "__main__":
    # 示例算法池
    algorithms_pool = [
        ("Algorithm A", 0.92),  # 排名1
        ("Algorithm B", 0.85),  # 排名2
        ("Algorithm C", 0.78),  # 排名3
        ("Algorithm D", 0.65),  # 排名4
    ]

    # 选择5次（可能重复）
    selected = choose(algorithms_pool, 100)
    print(selected)
    # 可能输出: [0, 0, 1, 2, 0]（A被选3次，B和C各1次）

    # 选择2次
    selected = choose(algorithms_pool, 1)
    print(selected)
    # 可能输出: [0, 1]（A和B）