import numpy as np
import random
from typing import List, Dict, Tuple
import copy
import numpy as np
import random
from typing import List, Dict, Tuple
import copy

class PSO:
    def __init__(
        self,
        evaluator: callable,
        num_planes: int,
        num_runways: int,
        planes: List[Dict],
        separation: List[List[float]],
        num_particles: int = 30,
        w: float = 0.8,
        c1: float = 2.0,
        c2: float = 2.0,
        w_decay: float = 0.99,
        max_stagnation: int = 50
    ):
        # 保留原有初始化代码不变
        self.evaluator = evaluator
        self.num_planes = num_planes
        self.num_runways = num_runways
        self.planes = planes
        self.separation = np.array(separation)
        
        self.num_particles = num_particles
        self.w = w
        self.c1 = c1
        self.c2 = c2
        self.w_decay = w_decay
        self.max_stagnation = max_stagnation
        
        self.earliest_landing_times = np.array([plane["earliest"] for plane in planes])
        self.target_landing_times = np.array([plane["target"] for plane in planes])
        self.latest_landing_times = np.array([plane["latest"] for plane in planes])
        self.penalty_early = np.array([plane['penalty_early'] for plane in planes])
        self.penalty_late = np.array([plane['penalty_late'] for plane in planes])
        
        self.positions = None
        self.velocities = None
        self.pbest_positions = None
        self.pbest_fitness = None
        self.gbest_position = None
        self.gbest_fitness = float('inf')
        
        self.stagnation_counter = 0
        self.previous_best_fitness = float('inf')
    
    def sequence2time(self, sequence):
        """保留您的原始函数"""
        import sys
        sys.path.append('/home/spcen/project/LLM4FWA')
        from linprog import solve_sequence_with_cost
        
        n = self.num_planes
        a = self.earliest_landing_times[sequence]
        b = self.latest_landing_times[sequence]
        c = self.target_landing_times[sequence]
        d = self.penalty_early[sequence]
        e = self.penalty_late[sequence]
        s = self.separation[sequence][:, sequence]
        
        return solve_sequence_with_cost(n, a, b, c, d, e, s)
    
    def _perturb_sequence(self, base_sequence, perturbation_strength=2):
        """
        对基础序列进行扰动，生成多样性初始解
        """
        sequence = base_sequence.copy()
        n = len(sequence)
        
        # 随机交换元素，扰动强度控制交换次数
        for _ in range(perturbation_strength):
            i, j = random.sample(range(n), 2)
            sequence[i], sequence[j] = sequence[j], sequence[i]
        
        return sequence
    
    def _sequence_to_continuous(self, sequence):
        """
        将离散序列转换为连续空间表示（随机键编码）
        使得argsort(continuous_vector) = sequence
        """
        n = len(sequence)
        continuous_vector = np.zeros(n)
        
        for rank, plane_index in enumerate(sequence):
            if n > 1:
                continuous_vector[plane_index] = rank / (n - 1)  # 归一化到[0,1]
            else:
                continuous_vector[plane_index] = 0.5  # 单飞机情况
        
        return continuous_vector
    
    def _continuous_to_sequence(self, continuous_position):
        """将连续位置向量转换为飞机着陆序列"""
        indices = np.argsort(continuous_position)
        return indices
    
    def _initialize_particles(self):
        """修改后的初始化方法：基于目标到达时间生成初始序列"""
        # 1. 生成基础序列：按目标到达时间排序
        target_landing_times = [self.planes[index]["target"] for index in range(self.num_planes)]
        base_sequence = np.argsort(target_landing_times)
        
        # 2. 初始化位置矩阵
        self.positions = np.zeros((self.num_particles, self.num_planes))
        
        # 3. 为每个粒子生成初始序列
        for i in range(self.num_particles):
            if i == 0:
                # 第一个粒子使用基础序列（按目标时间排序）
                sequence = base_sequence
            else:
                # 其他粒子使用扰动后的序列，增加多样性
                sequence = self._perturb_sequence(base_sequence, perturbation_strength=2)
            
            # 将序列转换为连续空间表示
            continuous_vector = self._sequence_to_continuous(sequence)
            self.positions[i] = continuous_vector
        
        # 4. 初始化速度（小随机值）
        self.velocities = np.random.uniform(-0.1, 0.1, (self.num_particles, self.num_planes))
        
        # 5. 初始化个体最优
        self.pbest_positions = self.positions.copy()
        self.pbest_fitness = np.full(self.num_particles, float('inf'))
        
        # 6. 评估初始粒子
        for i in range(self.num_particles):
            sequence = self._continuous_to_sequence(self.positions[i])
            times, cost = self.sequence2time(sequence)
            
            if cost != np.inf:
                runway_assignment = [1] * self.num_planes
                times = np.array([times[sequence.tolist().index(k)] for k in range(self.num_planes)])
                fitness = self.evaluator.compute((runway_assignment, times))
                
                self.pbest_fitness[i] = fitness
                if fitness < self.gbest_fitness:
                    self.gbest_fitness = fitness
                    self.gbest_position = self.positions[i].copy()
    
    # 保留其他方法不变（_update_velocity_and_position, _evaluate_particles等）
    def _update_velocity_and_position(self):
        """更新粒子速度和位置"""
        for i in range(self.num_particles):
            r1 = np.random.rand(self.num_planes)
            r2 = np.random.rand(self.num_planes)
            
            cognitive = self.c1 * r1 * (self.pbest_positions[i] - self.positions[i])
            social = self.c2 * r2 * (self.gbest_position - self.positions[i])
            self.velocities[i] = self.w * self.velocities[i] + cognitive + social
            
            velocity_max = 1.0
            self.velocities[i] = np.clip(self.velocities[i], -velocity_max, velocity_max)
            
            self.positions[i] += self.velocities[i]
            self.positions[i] = np.clip(self.positions[i], 0, 1)
    
    def _evaluate_particles(self):
        """评估所有粒子并更新最优解"""
        improved = False
        
        for i in range(self.num_particles):
            sequence = self._continuous_to_sequence(self.positions[i])
            times, cost = self.sequence2time(sequence)
            
            if cost != np.inf:
                runway_assignment = [1] * self.num_planes
                times = np.array([times[sequence.tolist().index(k)] for k in range(self.num_planes)])
                fitness = self.evaluator.compute((runway_assignment, times))
                
                if fitness < self.pbest_fitness[i]:
                    self.pbest_fitness[i] = fitness
                    self.pbest_positions[i] = self.positions[i].copy()
                    
                    if fitness < self.gbest_fitness:
                        self.gbest_fitness = fitness
                        self.gbest_position = self.positions[i].copy()
                        improved = True
        
        return improved
    
    def _update_inertia_weight(self):
        """更新惯性权重"""
        self.w *= self.w_decay
        self.w = max(0.4, min(0.9, self.w))
    
    def _check_stagnation(self):
        """检查停滞条件"""
        if abs(self.gbest_fitness - self.previous_best_fitness) < 1e-10:
            self.stagnation_counter += 1
        else:
            self.stagnation_counter = 0
        
        self.previous_best_fitness = self.gbest_fitness
        return self.stagnation_counter >= self.max_stagnation
    
    def optimize(self):
        """主优化过程"""
        self._initialize_particles()
        iteration = 0
        
        while not self.evaluator.stop():
            self._update_velocity_and_position()
            improved = self._evaluate_particles()
            self._update_inertia_weight()
            
            if self._check_stagnation():
                break
        
        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()


import numpy as np
import random
from typing import List, Dict, Tuple
import copy

class DE:
    def __init__(
        self,
        evaluator: callable,
        num_planes: int,
        num_runways: int,
        planes: List[Dict],
        separation: List[List[float]],
        pop_size: int = 50,
        F: float = 0.5,
        CR: float = 0.7,
        strategy: str = 'rand/1/bin',
        max_stagnation: int = 50
    ):
        """
        DE算法解决飞机跑道调度问题
        
        参数:
        evaluator: 评估器对象，包含compute(), stop(), get_best_solution(), get_best_fitness()方法
        num_planes: 飞机数量
        num_runways: 跑道数量
        planes: 飞机信息列表
        separation: 间隔矩阵
        pop_size: 种群大小
        F: 缩放因子
        CR: 交叉概率
        strategy: 变异策略 ('rand/1/bin', 'best/1/bin', 'rand-to-best/1/bin')
        max_stagnation: 最大停滞代数
        """
        self.evaluator = evaluator
        self.num_planes = num_planes
        self.num_runways = num_runways
        self.planes = planes
        self.separation = np.array(separation)
        
        # DE参数
        self.pop_size = pop_size
        self.F = F
        self.CR = CR
        self.strategy = strategy
        self.max_stagnation = max_stagnation
        
        # 飞机时间约束
        self.earliest_landing_times = np.array([plane["earliest"] for plane in planes])
        self.target_landing_times = np.array([plane["target"] for plane in planes])
        self.latest_landing_times = np.array([plane["latest"] for plane in planes])
        self.penalty_early = np.array([plane['penalty_early'] for plane in planes])
        self.penalty_late = np.array([plane['penalty_late'] for plane in planes])
        
        # 算法状态
        self.population = None  # 种群位置（连续空间）
        self.fitness = None  # 个体适应度
        self.best_individual = None  # 全局最优个体
        self.best_fitness = float('inf')  # 全局最优适应度
        
        # 早停机制
        self.stagnation_counter = 0
        self.previous_best_fitness = float('inf')
    
    def sequence2time(self, sequence):
        """
        计算给定序列的着陆时间和成本（保留您的原始函数）
        """
        import sys
        sys.path.append('/home/spcen/project/LLM4FWA')
        from linprog import solve_sequence_with_cost
        
        n = self.num_planes
        a = self.earliest_landing_times[sequence]
        b = self.latest_landing_times[sequence]
        c = self.target_landing_times[sequence]
        d = self.penalty_early[sequence]
        e = self.penalty_late[sequence]
        s = self.separation[sequence][:, sequence]
        
        return solve_sequence_with_cost(n, a, b, c, d, e, s)
    
    def _perturb_sequence(self, base_sequence, perturbation_strength=2):
        """
        对基础序列进行扰动，生成多样性初始解
        """
        sequence = base_sequence.copy()
        n = len(sequence)
        
        # 随机交换元素，扰动强度控制交换次数
        for _ in range(perturbation_strength):
            i, j = random.sample(range(n), 2)
            sequence[i], sequence[j] = sequence[j], sequence[i]
        
        return sequence
    
    def _sequence_to_continuous(self, sequence):
        """
        将离散序列转换为连续空间表示（随机键编码）
        使得argsort(continuous_vector) = sequence
        """
        n = len(sequence)
        continuous_vector = np.zeros(n)
        
        for rank, plane_index in enumerate(sequence):
            if n > 1:
                continuous_vector[plane_index] = rank / (n - 1)  # 归一化到[0,1]
            else:
                continuous_vector[plane_index] = 0.5  # 单飞机情况
        
        return continuous_vector
    
    def _continuous_to_sequence(self, continuous_position):
        """将连续位置向量转换为飞机着陆序列"""
        indices = np.argsort(continuous_position)
        return indices
    
    def _initialize_population(self):
        """初始化种群：基于目标到达时间生成初始序列（模仿FWA初始化）"""
        # 1. 生成基础序列：按目标到达时间排序
        target_landing_times = [self.planes[index]["target"] for index in range(self.num_planes)]
        base_sequence = np.argsort(target_landing_times)
        
        # 2. 初始化种群矩阵
        self.population = np.zeros((self.pop_size, self.num_planes))
        self.fitness = np.full(self.pop_size, float('inf'))
        
        # 3. 为每个个体生成初始序列
        for i in range(self.pop_size):
            if i == 0:
                # 第一个个体使用基础序列（按目标时间排序）
                sequence = base_sequence
            else:
                # 其他个体使用扰动后的序列，增加多样性
                sequence = self._perturb_sequence(base_sequence, perturbation_strength=2)
            
            # 将序列转换为连续空间表示
            continuous_vector = self._sequence_to_continuous(sequence)
            self.population[i] = continuous_vector
        
        # 4. 评估初始种群
        for i in range(self.pop_size):
            sequence = self._continuous_to_sequence(self.population[i])
            times, cost = self.sequence2time(sequence)
            
            if cost != np.inf:
                runway_assignment = [1] * self.num_planes
                times = np.array([times[sequence.tolist().index(k)] for k in range(self.num_planes)])
                fitness_val = self.evaluator.compute((runway_assignment, times))
                
                self.fitness[i] = fitness_val
                if fitness_val < self.best_fitness:
                    self.best_fitness = fitness_val
                    self.best_individual = self.population[i].copy()
    
    def _mutate(self, i):
        """
        变异操作：根据选择的策略生成变异向量[1,6](@ref)
        """
        # 随机选择三个不同的个体（不包括当前个体i）
        indices = [idx for idx in range(self.pop_size) if idx != i]
        a, b, c = self.population[np.random.choice(indices, 3, replace=False)]
        
        if self.strategy == 'rand/1/bin':
            # 基本变异策略: v = a + F * (b - c)
            mutant = a + self.F * (b - c)
        elif self.strategy == 'best/1/bin':
            # 使用最佳个体引导变异: v = best + F * (b - c)
            mutant = self.best_individual + self.F * (b - c)
        elif self.strategy == 'rand-to-best/1/bin':
            # 随机到最佳个体的变异: v = a + F * (best - a) + F * (b - c)
            mutant = a + self.F * (self.best_individual - a) + self.F * (b - c)
        else:
            # 默认使用rand/1/bin策略
            mutant = a + self.F * (b - c)
        
        return mutant
    
    def _crossover(self, target, mutant):
        """
        交叉操作：生成试验向量[1,8](@ref)
        """
        trial = np.copy(target)
        n_dim = target.shape[0]
        
        # 确保至少有一个维度来自变异向量
        j_rand = np.random.randint(0, n_dim)
        
        for j in range(n_dim):
            if np.random.rand() < self.CR or j == j_rand:
                trial[j] = mutant[j]
        
        return trial
    
    def _boundary_control(self, individual):
        """边界控制，确保个体在合理范围内[7](@ref)"""
        return np.clip(individual, 0, 1)
    
    def _check_stagnation(self):
        """检查是否陷入停滞"""
        if abs(self.best_fitness - self.previous_best_fitness) < 1e-10:
            self.stagnation_counter += 1
        else:
            self.stagnation_counter = 0
        
        self.previous_best_fitness = self.best_fitness
        return self.stagnation_counter >= self.max_stagnation
    
    def optimize(self):
        """
        主优化过程
        返回: (最佳解, 最佳适应度)
        """
        # 初始化种群
        self._initialize_population()
        
        # 主优化循环
        iteration = 0
        while not self.evaluator.stop():
            improved = False
            
            for i in range(self.pop_size):
                # 变异操作[1,6](@ref)
                mutant = self._mutate(i)
                
                # 交叉操作[1,8](@ref)
                trial = self._crossover(self.population[i], mutant)
                
                # 边界控制[7](@ref)
                trial = self._boundary_control(trial)
                
                # 转换为离散序列并评估
                sequence = self._continuous_to_sequence(trial)
                times, cost = self.sequence2time(sequence)
                
                if cost != np.inf:
                    runway_assignment = [1] * self.num_planes
                    times = np.array([times[sequence.tolist().index(k)] for k in range(self.num_planes)])
                    trial_fitness = self.evaluator.compute((runway_assignment, times))
                    
                    # 选择操作：贪婪选择[3,4](@ref)
                    if trial_fitness < self.fitness[i]:
                        self.population[i] = trial
                        self.fitness[i] = trial_fitness
                        
                        # 更新全局最优
                        if trial_fitness < self.best_fitness:
                            self.best_fitness = trial_fitness
                            self.best_individual = trial.copy()
                            improved = True
            
            iteration += 1
            
            # 检查早停条件
            if self._check_stagnation():
                print(f"早停：连续{self.max_stagnation}代没有改进")
                break
            
            # 可选：打印进度信息
            if iteration % 50 == 0:
                print(f"Iteration {iteration}, Best Fitness: {self.best_fitness:.4f}")
        
        # 返回评估器记录的最佳解
        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()
