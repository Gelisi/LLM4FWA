import numpy as np
import random

class PSO:
    def __init__(self, evaluator, n, num_particles=30, w=0.8, c1=2.0, c2=2.0, 
                 w_decay=0.99, max_stagnation=50):
        """
        PSO算法解决离散优化问题，确保1-8所有整数至少出现一次
        
        参数:
        evaluator: 评估器对象，包含compute(), stop(), get_best_solution(), get_best_fitness()方法
        n: 变量维度（必须大于等于8）
        num_particles: 粒子数量
        w: 惯性权重
        c1: 个体学习因子
        c2: 社会学习因子
        w_decay: 惯性权重衰减系数
        max_stagnation: 最大停滞代数
        """
        if n < 8:
            raise ValueError("n必须大于等于8，以确保1-8所有整数至少出现一次")
        
        self.evaluator = evaluator
        self.n = n
        self.num_particles = num_particles
        self.w = w
        self.c1 = c1
        self.c2 = c2
        self.w_decay = w_decay
        self.max_stagnation = max_stagnation
        
        # 搜索空间边界（连续表示）
        self.lb = 0.5  # 下界，对应离散值1
        self.ub = 8.5  # 上界，对应离散值8
        
        # 算法状态
        self.positions = None  # 粒子位置（连续空间）
        self.velocities = None  # 粒子速度
        self.pbest_positions = None  # 个体最优位置
        self.pbest_fitness = None  # 个体最优适应度
        self.gbest_position = None  # 全局最优位置
        self.gbest_fitness = float('inf')  # 全局最优适应度
        
        # 早停机制
        self.stagnation_counter = 0
        self.previous_best_fitness = float('inf')
    
    def _initialize_particles(self):
        """初始化粒子位置和速度"""
        # 在连续空间[0.5, 8.5]内随机初始化位置
        self.positions = np.random.uniform(self.lb, self.ub, (self.num_particles, self.n))
        
        # 初始化速度（较小随机值）
        self.velocities = np.random.uniform(-1, 1, (self.num_particles, self.n))
        
        # 初始化个体最优
        self.pbest_positions = self.positions.copy()
        self.pbest_fitness = np.full(self.num_particles, float('inf'))
        
        # 评估初始粒子
        for i in range(self.num_particles):
            discrete_sol = self._continuous_to_discrete(self.positions[i])
            repaired_sol = self._repair_solution(discrete_sol)
            fitness = self.evaluator.compute(repaired_sol)
            
            self.pbest_fitness[i] = fitness
            if fitness < self.gbest_fitness:
                self.gbest_fitness = fitness
                self.gbest_position = self.positions[i].copy()
    
    def _continuous_to_discrete(self, continuous_position):
        """将连续位置转换为离散整数（1-8）"""
        discrete = np.round(continuous_position).astype(int)
        discrete = np.clip(discrete, 1, 8)  # 确保在1-8范围内
        return discrete
    
    def _repair_solution(self, discrete_solution):
        """
        修复解：确保1-8所有整数至少出现一次
        使用最小化修改策略，尽量保持原解结构
        """
        # 检查已存在的数字
        present_numbers = set(discrete_solution)
        all_numbers = set(range(1, 9))  # 1-8
        
        # 如果已经满足约束，直接返回
        if present_numbers.issuperset(all_numbers):
            return discrete_solution
        
        # 复制原解
        repaired = discrete_solution.copy()
        missing_numbers = list(all_numbers - present_numbers)
        
        # 策略：用缺失数字替换重复出现的数字
        # 统计每个数字的出现次数
        from collections import Counter
        count = Counter(repaired)
        
        # 找出重复的数字（出现次数>1）
        duplicates = [num for num, cnt in count.items() if cnt > 1]
        
        if len(duplicates) >= len(missing_numbers):
            # 有足够重复数字可供替换
            replacement_indices = []
            for num in duplicates:
                # 找到该数字的所有位置
                indices = np.where(repaired == num)[0]
                # 保留一个，其余可用于替换
                if len(indices) > 1:
                    replacement_indices.extend(indices[1:min(len(indices), len(missing_numbers) + 1)])
            
            # 随机选择替换位置
            if len(replacement_indices) > len(missing_numbers):
                replacement_indices = np.random.choice(replacement_indices, len(missing_numbers), replace=False)
            
            # 执行替换
            for idx, new_num in zip(replacement_indices, missing_numbers):
                repaired[idx] = new_num
        else:
            # 没有足够重复数字，随机替换
            indices = list(range(len(repaired)))
            np.random.shuffle(indices)
            for idx, new_num in zip(indices[:len(missing_numbers)], missing_numbers):
                repaired[idx] = new_num
        
        return repaired
    
    def _update_velocity_and_position(self):
        """更新粒子速度和位置"""
        for i in range(self.num_particles):
            # 生成随机因子
            r1 = np.random.rand(self.n)
            r2 = np.random.rand(self.n)
            
            # 更新速度[1,3](@ref)
            cognitive = self.c1 * r1 * (self.pbest_positions[i] - self.positions[i])
            social = self.c2 * r2 * (self.gbest_position - self.positions[i])
            self.velocities[i] = self.w * self.velocities[i] + cognitive + social
            
            # 限制速度范围，防止发散[3](@ref)
            max_velocity = (self.ub - self.lb) * 0.2
            self.velocities[i] = np.clip(self.velocities[i], -max_velocity, max_velocity)
            
            # 更新位置
            self.positions[i] += self.velocities[i]
            
            # 边界处理[1](@ref)
            self.positions[i] = np.clip(self.positions[i], self.lb, self.ub)
    
    def _evaluate_particles(self):
        """评估所有粒子并更新最优解"""
        improved = False
        
        for i in range(self.num_particles):
            # 转换为离散解并修复
            discrete_sol = self._continuous_to_discrete(self.positions[i])
            repaired_sol = self._repair_solution(discrete_sol)
            
            # 计算适应度
            fitness = self.evaluator.compute(repaired_sol)
            
            # 更新个体最优
            if fitness < self.pbest_fitness[i]:
                self.pbest_fitness[i] = fitness
                self.pbest_positions[i] = self.positions[i].copy()
                
                # 更新全局最优
                if fitness < self.gbest_fitness:
                    self.gbest_fitness = fitness
                    self.gbest_position = self.positions[i].copy()
                    improved = True
        
        return improved
    
    def _update_inertia_weight(self):
        """更新惯性权重（线性衰减）[3](@ref)"""
        self.w *= self.w_decay
        self.w = max(0.4, min(0.9, self.w))  # 保持在合理范围内
    
    def optimize(self):
        """
        主优化过程
        返回: (最佳解, 最佳适应度)
        """
        self._initialize_particles()
        iteration = 0
        
        while not self.evaluator.stop():
            # 更新粒子速度和位置
            self._update_velocity_and_position()
            
            # 评估粒子并检查改进
            improved = self._evaluate_particles()
            
            # 更新惯性权重
            self._update_inertia_weight()
            
            # 早停检查
            if improved:
                self.stagnation_counter = 0
            else:
                self.stagnation_counter += 1
            
            if self.stagnation_counter >= self.max_stagnation:
                break
            
            iteration += 1
            
        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()


class DE:
    def __init__(self, evaluator, n, pop_size=50, F=0.5, CR=0.7, 
                 strategy='rand/1/bin', max_stagnation=50):
        """
        DE算法解决离散优化问题，确保1-8所有整数至少出现一次
        
        参数:
        evaluator: 评估器对象
        n: 变量维度（必须大于等于8）
        pop_size: 种群大小
        F: 缩放因子
        CR: 交叉概率
        strategy: 变异策略
        max_stagnation: 最大停滞代数
        """
        if n < 8:
            raise ValueError("n必须大于等于8，以确保1-8所有整数至少出现一次")
        
        self.evaluator = evaluator
        self.n = n
        self.pop_size = pop_size
        self.F = F
        self.CR = CR
        self.strategy = strategy
        self.max_stagnation = max_stagnation
        
        # 搜索空间边界
        self.lb = 0.5
        self.ub = 8.5
        
        # 算法状态
        self.population = None  # 种群位置（连续空间）
        self.fitness = None  # 个体适应度
        self.best_individual = None  # 全局最优个体
        self.best_fitness = float('inf')  # 全局最优适应度
        
        # 早停机制
        self.stagnation_counter = 0
    
    def _initialize_population(self):
        """初始化种群"""
        # 在连续空间内随机初始化
        self.population = np.random.uniform(self.lb, self.ub, (self.pop_size, self.n))
        self.fitness = np.full(self.pop_size, float('inf'))
        
        # 评估初始种群
        for i in range(self.pop_size):
            discrete_sol = self._continuous_to_discrete(self.population[i])
            repaired_sol = self._repair_solution(discrete_sol)
            fitness_val = self.evaluator.compute(repaired_sol)
            
            self.fitness[i] = fitness_val
            if fitness_val < self.best_fitness:
                self.best_fitness = fitness_val
                self.best_individual = self.population[i].copy()
    
    def _continuous_to_discrete(self, continuous_position):
        """将连续位置转换为离散整数（1-8）"""
        discrete = np.round(continuous_position).astype(int)
        discrete = np.clip(discrete, 1, 8)
        return discrete
    
    def _repair_solution(self, discrete_solution):
        """
        修复解：确保1-8所有整数至少出现一次
        """
        present_numbers = set(discrete_solution)
        all_numbers = set(range(1, 9))
        
        if present_numbers.issuperset(all_numbers):
            return discrete_solution
        
        repaired = discrete_solution.copy()
        missing_numbers = list(all_numbers - present_numbers)
        
        # 使用频率-based修复策略
        from collections import Counter
        count = Counter(repaired)
        
        # 优先替换出现次数最多的数字（保留多样性）
        if missing_numbers:
            # 找到出现次数最多的数字
            most_common = count.most_common(len(missing_numbers))
            replacement_numbers = [num for num, cnt in most_common[:len(missing_numbers)]]
            
            # 替换策略
            for i, missing_num in enumerate(missing_numbers):
                # 找到要替换的数字的第一个出现位置
                for j in range(len(repaired)):
                    if repaired[j] == replacement_numbers[i % len(replacement_numbers)]:
                        repaired[j] = missing_num
                        break
        
        return repaired
    
    def _mutate(self, i):
        """变异操作[6](@ref)"""
        # 随机选择三个不同的个体
        indices = [idx for idx in range(self.pop_size) if idx != i]
        a, b, c = self.population[np.random.choice(indices, 3, replace=False)]
        
        if self.strategy == 'rand/1/bin':
            mutant = a + self.F * (b - c)
        elif self.strategy == 'best/1/bin':
            mutant = self.best_individual + self.F * (b - c)
        else:
            mutant = a + self.F * (b - c)  # 默认策略
        
        return mutant
    
    def _crossover(self, target, mutant):
        """交叉操作[6](@ref)"""
        trial = np.copy(target)
        n_dim = target.shape[0]
        j_rand = np.random.randint(0, n_dim)  # 确保至少一个维度发生交叉
        
        for j in range(n_dim):
            if np.random.rand() < self.CR or j == j_rand:
                trial[j] = mutant[j]
        
        return trial
    
    def _boundary_control(self, individual):
        """边界控制"""
        return np.clip(individual, self.lb, self.ub)
    
    def optimize(self):
        """主优化过程"""
        self._initialize_population()
        iteration = 0
        
        while not self.evaluator.stop():
            improved = False
            
            for i in range(self.pop_size):
                # 变异操作
                mutant = self._mutate(i)
                
                # 交叉操作
                trial = self._crossover(self.population[i], mutant)
                
                # 边界处理
                trial = self._boundary_control(trial)
                
                # 转换为离散解并修复
                discrete_trial = self._continuous_to_discrete(trial)
                repaired_trial = self._repair_solution(discrete_trial)
                
                # 评估试验向量
                trial_fitness = self.evaluator.compute(repaired_trial)
                
                # 选择操作[6](@ref)
                if trial_fitness < self.fitness[i]:
                    self.population[i] = trial
                    self.fitness[i] = trial_fitness
                    
                    if trial_fitness < self.best_fitness:
                        self.best_fitness = trial_fitness
                        self.best_individual = trial.copy()
                        improved = True
            
            # 早停检查
            if improved:
                self.stagnation_counter = 0
            else:
                self.stagnation_counter += 1
            
            if self.stagnation_counter >= self.max_stagnation:
                break
            
            iteration += 1
        
        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()