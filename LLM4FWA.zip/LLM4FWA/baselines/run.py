import sys
sys.path.append('/home/spcen/project/LLM4FWA')
from evaluator import Evaluator
from utils import load_module
def optimize(dataset_name):
    eval_func = Evaluator(dataset_name)
    airplanes = load_module("airplanes", "/home/spcen/project/LLM4FWA/baselines/airplanes.py")
    print(eval_func.eval(airplanes))

if __name__ == "__main__":
    optimize("Aircraft landing")