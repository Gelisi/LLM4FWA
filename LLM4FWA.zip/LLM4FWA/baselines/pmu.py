import numpy as np
import random

class PSO:
    def __init__(self, evaluator, n, p, num_particles=30, w=0.8, c1=2.0, c2=2.0, w_decay=0.99, max_stagnation=50):
        """
        带约束的二进制PSO算法：确保解向量中恰好有p个1
        
        参数:
        evaluator: 评估器对象，包含compute(), stop(), get_best_solution(), get_best_fitness()方法
        n: 变量维度
        p: 解向量中1的个数
        num_particles: 粒子数量
        w: 惯性权重
        c1: 个体学习因子
        c2: 社会学习因子
        w_decay: 惯性权重衰减系数
        max_stagnation: 最大停滞代数，用于早停
        """
        self.evaluator = evaluator
        self.n = n  # 变量维度
        self.p = p  # 1的个数约束
        self.num_particles = num_particles
        self.w = w
        self.c1 = c1
        self.c2 = c2
        self.w_decay = w_decay
        self.max_stagnation = max_stagnation
        
        # 初始化粒子群
        self.positions = None  # 粒子位置（连续空间）
        self.velocities = None  # 粒子速度
        self.binary_positions = None  # 二进制位置（满足约束的解）
        self.personal_best_positions = None  # 个体最优位置（连续空间）
        self.personal_best_binary = None  # 个体最优二进制解
        self.personal_best_fitness = None  # 个体最优适应度
        self.global_best_position = None  # 全局最优位置（连续空间）
        self.global_best_binary = None  # 全局最优二进制解
        self.global_best_fitness = float('inf')  # 全局最优适应度
        
        # 早停计数器
        self.stagnation_counter = 0
        self.previous_best_fitness = float('inf')
    
    def _initialize_particles(self):
        """初始化粒子位置和速度"""
        # 在连续空间[0, 1]内随机初始化位置[1,3](@ref)
        self.positions = np.random.uniform(0, 1, (self.num_particles, self.n))
        
        # 初始化速度为零或小随机值[4](@ref)
        self.velocities = np.random.uniform(-0.1, 0.1, (self.num_particles, self.n))
        
        # 初始化个体最优
        self.personal_best_positions = self.positions.copy()
        self.personal_best_fitness = np.full(self.num_particles, float('inf'))
        
        # 生成初始二进制解并评估
        self.binary_positions = np.zeros((self.num_particles, self.n), dtype=int)
        self.personal_best_binary = np.zeros((self.num_particles, self.n), dtype=int)
        
        for i in range(self.num_particles):
            binary_sol = self._continuous_to_binary(self.positions[i])
            fitness = self.evaluator.compute(binary_sol)
            print(fitness)
            self.binary_positions[i] = binary_sol
            self.personal_best_binary[i] = binary_sol
            self.personal_best_fitness[i] = fitness
            
            if fitness < self.global_best_fitness:
                self.global_best_fitness = fitness
                self.global_best_position = self.positions[i].copy()
                self.global_best_binary = binary_sol.copy()
    
    def _continuous_to_binary(self, continuous_position):
        """
        将连续位置向量转换为二进制解，确保恰好有p个1[7](@ref)
        使用排序方法选择最大的p个值设为1，其余为0
        """
        # 获取最大的p个值的索引
        indices = np.argpartition(continuous_position, -self.p)[-self.p:]
        
        # 创建二进制解
        binary_solution = np.zeros(self.n, dtype=int)
        binary_solution[indices] = 1
        
        return binary_solution
    
    def _repair_solution(self, binary_solution):
        """
        修复解：如果不满足恰好p个1的约束，进行调整
        """
        ones_count = np.sum(binary_solution)
        
        if ones_count == self.p:
            return binary_solution  # 已经满足约束
        
        elif ones_count > self.p:
            # 1太多，随机将一些1变为0
            ones_indices = np.where(binary_solution == 1)[0]
            indices_to_remove = np.random.choice(ones_indices, ones_count - self.p, replace=False)
            binary_solution[indices_to_remove] = 0
            
        else:
            # 1太少，随机将一些0变为1
            zeros_indices = np.where(binary_solution == 0)[0]
            indices_to_add = np.random.choice(zeros_indices, self.p - ones_count, replace=False)
            binary_solution[indices_to_add] = 1
        
        return binary_solution
    
    def _update_velocity_and_position(self):
        """更新粒子速度和位置[4,6](@ref)"""
        for i in range(self.num_particles):
            # 生成随机因子
            r1 = np.random.rand(self.n)
            r2 = np.random.rand(self.n)
            
            # 更新速度[4](@ref)
            cognitive_component = self.c1 * r1 * (self.personal_best_positions[i] - self.positions[i])
            social_component = self.c2 * r2 * (self.global_best_position - self.positions[i])
            
            self.velocities[i] = (self.w * self.velocities[i] + 
                                 cognitive_component + 
                                 social_component)
            
            # 限制速度范围，防止发散[5](@ref)
            velocity_max = 1.0
            self.velocities[i] = np.clip(self.velocities[i], -velocity_max, velocity_max)
            
            # 更新位置
            self.positions[i] += self.velocities[i]
            
            # 限制位置范围在[0, 1]之间[1](@ref)
            self.positions[i] = np.clip(self.positions[i], 0, 1)
            
            # 将连续位置转换为二进制解
            new_binary = self._continuous_to_binary(self.positions[i])
            self.binary_positions[i] = new_binary
    
    def _evaluate_particles(self):
        """评估所有粒子并更新最优解"""
        improved = False
        
        for i in range(self.num_particles):
            # 确保解满足约束（修复可能的不满足约束的解）
            repaired_binary = self._repair_solution(self.binary_positions[i].copy())
            
            # 计算适应度
            fitness = self.evaluator.compute(repaired_binary)
            # 更新个体最优
            if fitness < self.personal_best_fitness[i]:
                self.personal_best_fitness[i] = fitness
                self.personal_best_positions[i] = self.positions[i].copy()
                self.personal_best_binary[i] = repaired_binary.copy()
                
                # 更新全局最优
                if fitness < self.global_best_fitness:
                    self.global_best_fitness = fitness
                    self.global_best_position = self.positions[i].copy()
                    self.global_best_binary = repaired_binary.copy()
                    improved = True
        
        return improved
    
    def _update_inertia_weight(self):
        """更新惯性权重（线性衰减）[4,5](@ref)"""
        self.w *= self.w_decay
        # 确保惯性权重在合理范围内
        self.w = max(0.4, min(0.9, self.w))
    
    def _check_stagnation(self, current_best_fitness):
        """检查是否陷入停滞"""
        if abs(current_best_fitness - self.previous_best_fitness) < 1e-10:
            self.stagnation_counter += 1
        else:
            self.stagnation_counter = 0
        
        self.previous_best_fitness = current_best_fitness
        
        return self.stagnation_counter >= self.max_stagnation
    
    def optimize(self):
        """
        主优化过程
        返回: (最佳解向量, 最佳适应度)
        """
        # 初始化粒子群
        self._initialize_particles()
        
        # 主优化循环
        iteration = 0
        while not self.evaluator.stop():
            # 更新粒子速度和位置
            self._update_velocity_and_position()
            
            # 评估粒子并检查是否有改进
            improved = self._evaluate_particles()
            
            # 更新惯性权重
            self._update_inertia_weight()
            
            # 检查停滞条件
            if self._check_stagnation(self.global_best_fitness):
                break
            
            iteration += 1
            

        # 返回评估器记录的最佳解
        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()


import numpy as np
import random

class DE:
    def __init__(self, evaluator, n, p, pop_size=50, F=0.5, CR=0.7, 
                 strategy='rand/1/bin', max_stagnation=50):
        """
        带约束的二进制差分进化算法：确保解向量中恰好有p个1
        
        参数:
        evaluator: 评估器对象，包含compute(), stop(), get_best_solution(), get_best_fitness()方法
        n: 变量维度
        p: 解向量中1的个数
        pop_size: 种群大小
        F: 缩放因子（变异强度）
        CR: 交叉概率
        strategy: 变异策略，支持'rand/1/bin', 'best/1/bin', 'rand-to-best/1/bin'等
        max_stagnation: 最大停滞代数，用于早停
        """
        self.evaluator = evaluator
        self.n = n  # 变量维度
        self.p = p  # 1的个数约束
        self.pop_size = pop_size
        self.F = F  # 缩放因子
        self.CR = CR  # 交叉概率
        self.strategy = strategy  # 变异策略
        self.max_stagnation = max_stagnation
        
        # 初始化种群
        self.population = None  # 种群位置（连续空间）
        self.binary_population = None  # 二进制种群（满足约束的解）
        self.fitness = None  # 种群适应度
        self.best_individual = None  # 全局最优个体（连续空间）
        self.best_binary = None  # 全局最优二进制解
        self.best_fitness = float('inf')  # 全局最优适应度
        
        # 早停计数器
        self.stagnation_counter = 0
        self.previous_best_fitness = float('inf')
    
    def _initialize_population(self):
        """初始化种群"""
        # 在连续空间[0, 1]内随机初始化种群[3](@ref)
        self.population = np.random.uniform(0, 1, (self.pop_size, self.n))
        self.fitness = np.full(self.pop_size, float('inf'))
        self.binary_population = np.zeros((self.pop_size, self.n), dtype=int)
        
        # 评估初始种群
        for i in range(self.pop_size):
            binary_sol = self._continuous_to_binary(self.population[i])
            fitness_val = self.evaluator.compute(binary_sol)
            
            self.binary_population[i] = binary_sol
            self.fitness[i] = fitness_val
            
            if fitness_val < self.best_fitness:
                self.best_fitness = fitness_val
                self.best_individual = self.population[i].copy()
                self.best_binary = binary_sol.copy()
    
    def _continuous_to_binary(self, continuous_position):
        """
        将连续位置向量转换为二进制解，确保恰好有p个1[2](@ref)
        使用排序方法选择最大的p个值设为1，其余为0
        """
        # 获取最大的p个值的索引
        indices = np.argpartition(continuous_position, -self.p)[-self.p:]
        
        # 创建二进制解
        binary_solution = np.zeros(self.n, dtype=int)
        binary_solution[indices] = 1
        
        return binary_solution
    
    def _repair_solution(self, binary_solution):
        """
        修复解：如果不满足恰好p个1的约束，进行调整[2](@ref)
        """
        ones_count = np.sum(binary_solution)
        
        if ones_count == self.p:
            return binary_solution  # 已经满足约束
        
        elif ones_count > self.p:
            # 1太多，随机将一些1变为0
            ones_indices = np.where(binary_solution == 1)[0]
            indices_to_remove = np.random.choice(ones_indices, ones_count - self.p, replace=False)
            repaired = binary_solution.copy()
            repaired[indices_to_remove] = 0
            
        else:
            # 1太少，随机将一些0变为1
            zeros_indices = np.where(binary_solution == 0)[0]
            indices_to_add = np.random.choice(zeros_indices, self.p - ones_count, replace=False)
            repaired = binary_solution.copy()
            repaired[indices_to_add] = 1
        
        return repaired
    
    def _mutate(self, i):
        """
        变异操作：根据选择的策略生成变异向量[5,6](@ref)
        """
        # 随机选择三个不同的个体（不包括当前个体i）
        indices = [idx for idx in range(self.pop_size) if idx != i]
        a, b, c = self.population[np.random.choice(indices, 3, replace=False)]
        
        if self.strategy == 'rand/1/bin':
            # 基本变异策略: v = a + F * (b - c)
            mutant = a + self.F * (b - c)
        elif self.strategy == 'best/1/bin':
            # 使用最佳个体引导变异: v = best + F * (b - c)
            mutant = self.best_individual + self.F * (b - c)
        elif self.strategy == 'rand-to-best/1/bin':
            # 随机到最佳个体的变异: v = a + F * (best - a) + F * (b - c)
            mutant = a + self.F * (self.best_individual - a) + self.F * (b - c)
        else:
            # 默认使用rand/1/bin策略
            mutant = a + self.F * (b - c)
        
        return mutant
    
    def _crossover(self, target, mutant):
        """
        交叉操作：生成试验向量[5,6](@ref)
        """
        trial = np.copy(target)
        n_dim = target.shape[0]
        
        # 确保至少有一个维度来自变异向量
        j_rand = np.random.randint(0, n_dim)
        
        for j in range(n_dim):
            if np.random.rand() < self.CR or j == j_rand:
                trial[j] = mutant[j]
        
        return trial
    
    def _boundary_control(self, individual):
        """边界控制，确保个体在合理范围内[4](@ref)"""
        return np.clip(individual, 0, 1)
    
    def _check_stagnation(self, current_best_fitness):
        """检查是否陷入停滞"""
        if abs(current_best_fitness - self.previous_best_fitness) < 1e-10:
            self.stagnation_counter += 1
        else:
            self.stagnation_counter = 0
        
        self.previous_best_fitness = current_best_fitness
        
        return self.stagnation_counter >= self.max_stagnation
    
    def optimize(self):
        """
        主优化过程
        返回: (最佳解向量, 最佳适应度)
        """
        # 初始化种群
        self._initialize_population()
        
        # 主优化循环
        iteration = 0
        while not self.evaluator.stop():
            improved = False
            
            for i in range(self.pop_size):
                # 变异操作
                mutant = self._mutate(i)
                
                # 交叉操作
                trial = self._crossover(self.population[i], mutant)
                
                # 边界控制
                trial = self._boundary_control(trial)
                
                # 将连续向量转换为二进制解
                trial_binary = self._continuous_to_binary(trial)
                
                # 修复解确保满足约束
                repaired_trial = self._repair_solution(trial_binary)
                
                # 评估试验向量
                trial_fitness = self.evaluator.compute(repaired_trial)
                
                # 选择操作：贪婪选择[4](@ref)
                if trial_fitness < self.fitness[i]:
                    self.population[i] = trial
                    self.binary_population[i] = repaired_trial
                    self.fitness[i] = trial_fitness
                    
                    # 更新全局最优
                    if trial_fitness < self.best_fitness:
                        self.best_fitness = trial_fitness
                        self.best_individual = trial.copy()
                        self.best_binary = repaired_trial.copy()
                        improved = True
            
            iteration += 1
            
            # 检查停滞条件
            if self._check_stagnation(self.best_fitness):
                break
            
        
        # 返回评估器记录的最佳解
        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()
