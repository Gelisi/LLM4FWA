import numpy as np
import random

class PSO:
    def __init__(self, evaluator, n, num_particles=30, w=0.8, c1=2.0, c2=2.0, w_decay=0.99):
        """
        PSO算法解决流水车间调度问题
        
        参数:
        evaluator: 评估器对象，包含compute(), stop(), get_best_solution(), get_best_fitness()方法
        n: 工件数量（搜索空间维度）
        num_particles: 粒子数量
        w: 惯性权重
        c1: 个体学习因子
        c2: 社会学习因子
        w_decay: 惯性权重衰减系数
        """
        self.evaluator = evaluator
        self.n = n  # 工件数量
        self.num_particles = num_particles
        self.w = w  # 惯性权重
        self.c1 = c1  # 个体学习因子
        self.c2 = c2  # 社会学习因子
        self.w_decay = w_decay  # 惯性权重衰减
        self.silent_counter = 0
        # 初始化粒子群
        self.positions = None  # 粒子位置（连续空间）
        self.velocities = None  # 粒子速度
        self.personal_best_positions = None  # 个体最优位置
        self.personal_best_fitness = None  # 个体最优适应度
        self.global_best_position = None  # 全局最优位置（连续空间）
        self.global_best_fitness = float('inf')  # 全局最优适应度
        
        # 最佳调度序列和适应度
        self.best_schedule = None
        self.best_fitness = float('inf')
    
    def _initialize_particles(self):
        """初始化粒子位置和速度"""
        # 在连续空间[-1, 1]内随机初始化位置
        self.positions = np.random.uniform(-1, 1, (self.num_particles, self.n))
        
        # 初始化速度为零或小随机值
        self.velocities = np.random.uniform(-0.1, 0.1, (self.num_particles, self.n))
        
        # 初始化个体最优
        self.personal_best_positions = self.positions.copy()
        self.personal_best_fitness = np.full(self.num_particles, float('inf'))
        
        # 评估初始粒子
        for i in range(self.num_particles):
            schedule = self._continuous_to_schedule(self.positions[i])
            fitness = self.evaluator.compute(schedule)
            
            self.personal_best_fitness[i] = fitness
            if fitness < self.global_best_fitness:
                self.global_best_fitness = fitness
                self.global_best_position = self.positions[i].copy()
                self.best_schedule = schedule.copy()
                self.best_fitness = fitness
    
    def _continuous_to_schedule(self, continuous_position):
        """
        将连续位置向量转换为离散调度序列
        使用随机键（Random Key）编码方式
        """
        # 对连续值进行排序，索引即为调度序列
        indices = np.argsort(continuous_position)
        # 转换为1~n的排列
        schedule = indices + 1
        return schedule
    
    def _update_velocity_and_position(self):
        """更新粒子速度和位置"""
        for i in range(self.num_particles):
            # 生成随机因子
            r1 = np.random.rand(self.n)
            r2 = np.random.rand(self.n)
            
            # 更新速度[1](@ref)
            cognitive_component = self.c1 * r1 * (self.personal_best_positions[i] - self.positions[i])
            social_component = self.c2 * r2 * (self.global_best_position - self.positions[i])
            
            self.velocities[i] = (self.w * self.velocities[i] + 
                                 cognitive_component + 
                                 social_component)
            
            # 限制速度范围，防止发散
            velocity_max = 1.0
            self.velocities[i] = np.clip(self.velocities[i], -velocity_max, velocity_max)
            
            # 更新位置
            self.positions[i] += self.velocities[i]
            
            # 限制位置范围
            self.positions[i] = np.clip(self.positions[i], -2, 2)
    
    def _evaluate_particles(self):
        """评估所有粒子并更新最优解"""
        self.flag = False
        for i in range(self.num_particles):
            # 将连续位置转换为调度序列
            schedule = self._continuous_to_schedule(self.positions[i])
            
            # 计算适应度
            fitness = self.evaluator.compute(schedule)
            
            # 更新个体最优
            if fitness < self.personal_best_fitness[i]:
                self.personal_best_fitness[i] = fitness
                self.personal_best_positions[i] = self.positions[i].copy()
                
                # 更新全局最优
                if fitness < self.global_best_fitness:
                    self.global_best_fitness = fitness
                    self.global_best_position = self.positions[i].copy()
                    self.best_schedule = schedule.copy()
                    self.best_fitness = fitness
                    self.flag = True
    
    def _update_inertia_weight(self):
        """更新惯性权重（线性衰减）[5](@ref)"""
        self.w *= self.w_decay
    
    def optimize(self):
        """
        主优化过程
        返回: (最佳调度序列, 最佳适应度)
        """
        # 初始化粒子群
        self._initialize_particles()
        
        # 主优化循环
        iteration = 0
        while not self.evaluator.stop():
            # 更新粒子速度和位置
            self._update_velocity_and_position()
            
            # 评估粒子
            self._evaluate_particles()
            
            # 更新惯性权重
            self._update_inertia_weight()
            
            iteration += 1

            if self.flag == False:
                self.silent_counter += 1
            else:
                self.silent_counter = 0

            if self.silent_counter >= 50:
                break
            
        # 返回评估器记录的最佳解
        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()



class DE:
    def __init__(self, evaluator, n, pop_size=50, F=0.5, CR=0.7, strategy='rand/1/bin'):
        """
        DE算法解决流水车间调度问题
        
        参数:
        evaluator: 评估器对象，包含compute(), stop(), get_best_solution(), get_best_fitness()方法
        n: 工件数量（搜索空间维度）
        pop_size: 种群大小
        F: 缩放因子（变异强度）
        CR: 交叉概率
        strategy: 变异策略，支持'rand/1/bin', 'best/1/bin', 'rand-to-best/1/bin'等
        """
        self.evaluator = evaluator
        self.n = n  # 工件数量
        self.pop_size = pop_size
        self.F = F  # 缩放因子
        self.CR = CR  # 交叉概率
        self.strategy = strategy  # 变异策略
        
        # 初始化种群
        self.population = None  # 种群位置（连续空间）
        self.fitness = None  # 种群适应度
        self.best_individual = None  # 全局最优个体（连续空间）
        self.best_fitness = float('inf')  # 全局最优适应度
        
        # 最佳调度序列和适应度
        self.best_schedule = None
        self.best_fitness_value = float('inf')
        
        # 早停计数器
        self.silent_counter = 0
    
    def _initialize_population(self):
        """初始化种群"""
        # 在连续空间[-1, 1]内随机初始化种群
        self.population = np.random.uniform(-1, 1, (self.pop_size, self.n))
        self.fitness = np.full(self.pop_size, float('inf'))
        
        # 评估初始种群
        for i in range(self.pop_size):
            schedule = self._continuous_to_schedule(self.population[i])
            fitness_val = self.evaluator.compute(schedule)
            self.fitness[i] = fitness_val
            
            if fitness_val < self.best_fitness:
                self.best_fitness = fitness_val
                self.best_individual = self.population[i].copy()
                self.best_schedule = schedule.copy()
                self.best_fitness_value = fitness_val
    
    def _continuous_to_schedule(self, continuous_position):
        """
        将连续位置向量转换为离散调度序列
        使用随机键（Random Key）编码方式
        """
        # 对连续值进行排序，索引即为调度序列
        indices = np.argsort(continuous_position)
        # 转换为1~n的排列
        schedule = indices + 1
        return schedule
    
    def _mutate(self, i):
        """
        变异操作：根据选择的策略生成变异向量
        """
        # 随机选择三个不同的个体（不包括当前个体i）
        indices = [idx for idx in range(self.pop_size) if idx != i]
        a, b, c = self.population[np.random.choice(indices, 3, replace=False)]
        
        if self.strategy == 'rand/1/bin':
            # 基本变异策略: v = a + F * (b - c)
            mutant = a + self.F * (b - c)
        elif self.strategy == 'best/1/bin':
            # 使用最佳个体引导变异: v = best + F * (b - c)
            mutant = self.best_individual + self.F * (b - c)
        elif self.strategy == 'rand-to-best/1/bin':
            # 随机到最佳个体的变异: v = a + F * (best - a) + F * (b - c)
            mutant = a + self.F * (self.best_individual - a) + self.F * (b - c)
        else:
            # 默认使用rand/1/bin策略
            mutant = a + self.F * (b - c)
        
        return mutant
    
    def _crossover(self, target, mutant):
        """
        交叉操作：生成试验向量
        """
        trial = np.copy(target)
        
        # 确保至少有一个维度来自变异向量
        j_rand = np.random.randint(0, self.n)
        
        for j in range(self.n):
            if np.random.rand() < self.CR or j == j_rand:
                trial[j] = mutant[j]
        
        return trial
    
    def _boundary_control(self, individual):
        """边界控制，确保个体在合理范围内"""
        return np.clip(individual, -2, 2)
    
    def optimize(self):
        """
        主优化过程
        返回: (最佳调度序列, 最佳适应度)
        """
        # 初始化种群
        self._initialize_population()
        
        # 主优化循环
        iteration = 0
        improved = False
        
        while not self.evaluator.stop():
            improved = False
            
            for i in range(self.pop_size):
                # 变异操作
                mutant = self._mutate(i)
                
                # 交叉操作
                trial = self._crossover(self.population[i], mutant)
                
                # 边界控制
                trial = self._boundary_control(trial)
                
                # 评估试验向量
                trial_schedule = self._continuous_to_schedule(trial)
                trial_fitness = self.evaluator.compute(trial_schedule)
                
                # 选择操作：贪婪选择
                if trial_fitness < self.fitness[i]:
                    self.population[i] = trial
                    self.fitness[i] = trial_fitness
                    
                    # 更新全局最优
                    if trial_fitness < self.best_fitness:
                        self.best_fitness = trial_fitness
                        self.best_individual = trial.copy()
                        self.best_schedule = trial_schedule.copy()
                        self.best_fitness_value = trial_fitness
                        improved = True
            
            iteration += 1
            
            # 早停机制：如果连续多代没有改进，则提前停止
            if improved:
                self.silent_counter = 0
            else:
                self.silent_counter += 1
            
            if self.silent_counter >= 50:
                break
            
        
        # 返回评估器记录的最佳解
        return self.evaluator.get_best_solution(), self.evaluator.get_best_fitness()


