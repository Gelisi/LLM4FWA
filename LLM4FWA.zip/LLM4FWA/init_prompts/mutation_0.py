def get_mutation_prompts(problem_description, current_code, current_perfomance):
    introduction = f"You are an expert in combinatorial optimization and firework algorithms, now you are faced with a probelm:{problem_description}.\n"
    current_fwa = f"I will show you one firework algorithm for solving it:{current_code}. Its performance is {current_perfomance}. The higher performance, the better.\n" 
    requirements = "1. Please choose exactly one of the functions in 'explode', 'mutate' and 'select' of our current code and replace it by your new design.\n" \
                 + "2. You can only redesign the function you choose, keeping the input and output the same, but do not change other functions.\n" \
                 + "3. Only return the complete code of the firework algorithm in the format: <code>xxx</code> and do not explain anything"
    prompt_mutation = introduction + current_fwa + requirements
    return prompt_mutation