def get_crossover_prompts(problem_description, current_codes, current_perfomances):
    introduction = f"You are an expert in combinatorial optimization and firework algorithms, now you are faced with a probelm:{problem_description}.\n"
    current_fwa = f"I will show you two firework algorithms for solving it. The first code:{current_codes[0]} and its performance is {current_perfomances[0]}; the second code:{current_codes[1]} and its performance is {current_perfomances[1]}. The higher performance, the better.\n" 
    requirements = "1. Please crossover the functions in 'explode', 'mutate' and 'select' based on our current codes and get a more powerful algorithm.\n" \
                 + "2. You should keep the input and output the same, but do not change other functions.\n" \
                 + "3. Only return the complete code of the firework algorithm in the format: <code>xxx</code> and do not explain anything"
    prompt_crossover = introduction + current_fwa + requirements
    return prompt_crossover